import { UserRecord, dbService } from './firebase.ts';

export interface AdRewardResult {
  success: boolean;
  message: string;
  coinsAwarded?: number;
  remainingAdsToday?: number;
  nextAvailableInSeconds?: number;
}

export class AdService {
  public verifyAndReward(user: UserRecord, zoneId?: string): AdRewardResult {
    const settings = dbService.getSettings();
    const now = Date.now();
    const todayStr = new Date().toISOString().split('T')[0];

    // Check account status
    if (user.status === 'banned') {
      return { success: false, message: 'Account is banned.' };
    }

    // Reset daily count if date changed
    if (!user.rewards.ads || user.rewards.ads.todayDate !== todayStr) {
      user.rewards.ads = {
        lastWatchedAt: 0,
        todayCount: 0,
        todayDate: todayStr,
      };
    }

    // 1. Check Max Ads Per Day
    if (user.rewards.ads.todayCount >= settings.maxRewardedAdsPerDay) {
      return {
        success: false,
        message: `You reached the daily limit of ${settings.maxRewardedAdsPerDay} ads for today. Come back tomorrow!`,
        remainingAdsToday: 0,
      };
    }

    // 2. Check Cooldown
    const elapsedSinceLastAd = Math.floor((now - user.rewards.ads.lastWatchedAt) / 1000);
    if (elapsedSinceLastAd < settings.adCooldownSeconds) {
      const waitTime = settings.adCooldownSeconds - elapsedSinceLastAd;
      return {
        success: false,
        message: `Ad cooldown in effect. Please wait ${waitTime}s before watching another ad.`,
        nextAvailableInSeconds: waitTime,
      };
    }

    // 3. Award Reward
    const rewardAmount = settings.rewardPerAd;
    const balanceBefore = user.balance;
    user.balance += rewardAmount;
    user.rewards.ads.todayCount += 1;
    user.rewards.ads.lastWatchedAt = now;
    user.statistics.totalAdRewards += rewardAmount;

    // 4. Log Transaction
    dbService.createTransaction({
      userId: user.profile.telegramId,
      type: 'ad_reward',
      amount: rewardAmount,
      balanceBefore,
      balanceAfter: user.balance,
      note: `Watched Monetag rewarded ad (Zone: ${zoneId || 'default'})`,
    });

    dbService.saveUser(user);

    return {
      success: true,
      message: `Congratulations! You received +${rewardAmount.toLocaleString()} coins!`,
      coinsAwarded: rewardAmount,
      remainingAdsToday: settings.maxRewardedAdsPerDay - user.rewards.ads.todayCount,
      nextAvailableInSeconds: settings.adCooldownSeconds,
    };
  }
}

export const adService = new AdService();
