import crypto from 'crypto';

export interface TelegramUserData {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

export interface VerificationResult {
  isValid: boolean;
  user?: TelegramUserData;
  startParam?: string;
  authDate?: number;
  error?: string;
}

export class TelegramService {
  private botToken: string;
  private webAppUrl: string;

  constructor() {
    this.botToken = process.env.BOT_TOKEN || '[CHANGE_ME_BOT_TOKEN]';
    this.webAppUrl = process.env.WEB_APP_URL || '';
  }

  public getBotToken(): string {
    return this.botToken;
  }

  public isBotTokenConfigured(): boolean {
    return (
      !!this.botToken &&
      !this.botToken.includes('[CHANGE_ME_') &&
      !this.botToken.includes('YOUR_NEW_BOT_TOKEN')
    );
  }

  /**
   * Validates Telegram WebApp initData HMAC-SHA256 signature
   * Reference: https://core.telegram.org/bots/webapps#validating-data-received-via-the-web-app
   */
  public verifyInitData(initDataString: string): VerificationResult {
    if (!initDataString || typeof initDataString !== 'string') {
      return { isValid: false, error: 'Empty initData provided' };
    }

    try {
      const urlParams = new URLSearchParams(initDataString);
      const hash = urlParams.get('hash');
      const startParam = urlParams.get('start_param') || undefined;
      const authDate = Number(urlParams.get('auth_date') || 0);

      // Handle Development / Preview Mode when bot token is not yet configured or simulation flag
      if (!this.isBotTokenConfigured()) {
        const rawUser = urlParams.get('user');
        if (rawUser) {
          const user = JSON.parse(rawUser) as TelegramUserData;
          return {
            isValid: true,
            user,
            startParam,
            authDate: authDate || Math.floor(Date.now() / 1000),
          };
        }
      }

      if (!hash) {
        return { isValid: false, error: 'Missing hash in initData' };
      }

      // Check auth date staleness (allow within 24 hours)
      const now = Math.floor(Date.now() / 1000);
      if (authDate > 0 && now - authDate > 86400 * 7) {
        return { isValid: false, error: 'InitData has expired' };
      }

      // 1. Sort all parameters alphabetically, excluding 'hash'
      const pairs: string[] = [];
      const keys = Array.from(urlParams.keys()).sort();
      for (const key of keys) {
        if (key !== 'hash') {
          pairs.push(`${key}=${urlParams.get(key)}`);
        }
      }
      const dataCheckString = pairs.join('\n');

      // 2. Compute secret key: HMAC_SHA256(key="WebAppData", msg=botToken)
      const secretKey = crypto
        .createHmac('sha256', 'WebAppData')
        .update(this.botToken)
        .digest();

      // 3. Compute hash: HMAC_SHA256(key=secretKey, msg=dataCheckString)
      const calculatedHash = crypto
        .createHmac('sha256', secretKey)
        .update(dataCheckString)
        .digest('hex');

      // 4. Secure comparison
      const isValid = crypto.timingSafeEqual(
        Buffer.from(calculatedHash, 'hex'),
        Buffer.from(hash, 'hex')
      );

      if (!isValid) {
        return { isValid: false, error: 'HMAC signature verification failed' };
      }

      const rawUser = urlParams.get('user');
      const user = rawUser ? (JSON.parse(rawUser) as TelegramUserData) : undefined;

      return {
        isValid: true,
        user,
        startParam,
        authDate,
      };
    } catch (err: any) {
      return { isValid: false, error: `Verification error: ${err.message}` };
    }
  }

  /**
   * Sends a message via Telegram Bot API
   */
  public async sendMessage(chatId: string | number, text: string, replyMarkup?: any): Promise<boolean> {
    if (!this.isBotTokenConfigured()) {
      console.log(`[Telegram Simulation] Send to ${chatId}: ${text}`);
      return true;
    }

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const body: any = {
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
      };
      if (replyMarkup) {
        body.reply_markup = replyMarkup;
      }

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      return !!data.ok;
    } catch (err) {
      console.error('Telegram Bot sendMessage error:', err);
      return false;
    }
  }

  /**
   * Generates the standard welcome keyboard with "OPEN APP 🚀"
   */
  public getWebAppStartKeyboard(webAppUrl?: string) {
    const url = webAppUrl || this.webAppUrl;
    return {
      inline_keyboard: [
        [
          {
            text: 'OPEN APP 🚀',
            web_app: { url },
          },
        ],
        [
          {
            text: 'Official Community 💬',
            url: 'https://t.me',
          },
        ],
      ],
    };
  }

  /**
   * Broadcasts message to multiple users
   */
  public async broadcast(
    userIds: string[],
    message: string
  ): Promise<{ successCount: number; failureCount: number; failedIds: string[] }> {
    let successCount = 0;
    let failureCount = 0;
    const failedIds: string[] = [];

    for (const id of userIds) {
      try {
        const ok = await this.sendMessage(id, message);
        if (ok) {
          successCount++;
        } else {
          failureCount++;
          failedIds.push(id);
        }
        // Small delay to respect Telegram rate limits (30 msg/sec)
        await new Promise((resolve) => setTimeout(resolve, 40));
      } catch {
        failureCount++;
        failedIds.push(id);
      }
    }

    return { successCount, failureCount, failedIds };
  }
}

export const telegramService = new TelegramService();
