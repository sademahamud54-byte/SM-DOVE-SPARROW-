import fs from 'fs';
import path from 'path';

export interface UserProfile {
  telegramId: string;
  firstName: string;
  lastName?: string;
  username?: string;
  languageCode?: string;
  photoUrl?: string;
  createdAt: number;
  lastLoginAt: number;
}

export interface UserEnergy {
  current: number;
  max: number;
  rechargeRate: number; // energy per second
  lastUpdated: number;
}

export interface UserMining {
  coinsPerHour: number;
  lastClaimedAt: number;
}

export interface UserUpgrades {
  tapPower: number;
  maxEnergy: number;
  rechargeRate: number;
  miningRate: number;
  multiplier: number;
}

export interface UserReferrals {
  referrerId?: string;
  totalReferred: number;
  totalEarned: number;
  referredUsers: Array<{
    telegramId: string;
    username?: string;
    bonusEarned: number;
    joinedAt: number;
  }>;
}

export interface UserRewards {
  dailyStreak: {
    currentDay: number; // 1 to 7
    lastClaimDate: string; // 'YYYY-MM-DD'
  };
  ads: {
    lastWatchedAt: number;
    todayCount: number;
    todayDate: string; // 'YYYY-MM-DD'
  };
}

export interface UserRecord {
  profile: UserProfile;
  balance: number;
  energy: UserEnergy;
  level: {
    current: number;
    title: string;
    progress: number;
  };
  mining: UserMining;
  upgrades: UserUpgrades;
  referrals: UserReferrals;
  rewards: UserRewards;
  tasks: Record<string, { completed: boolean; claimedAt: number }>;
  statistics: {
    totalTaps: number;
    totalMined: number;
    totalAdRewards: number;
    totalTaskRewards: number;
    totalReferralRewards: number;
  };
  status: 'active' | 'banned' | 'suspended';
}

export interface TransactionRecord {
  id: string;
  userId: string;
  type:
    | 'welcome_bonus'
    | 'tap'
    | 'mining'
    | 'upgrade'
    | 'daily_reward'
    | 'task_reward'
    | 'ad_reward'
    | 'referral_bonus'
    | 'admin_adjustment'
    | 'penalty';
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  note?: string;
  timestamp: number;
}

export interface TaskDefinition {
  id: string;
  title: string;
  description: string;
  link: string;
  reward: number;
  type: 'telegram_channel' | 'telegram_group' | 'website' | 'twitter' | 'referral' | 'custom';
  status: 'active' | 'inactive';
  requiredCount?: number;
}

export interface GameSettings {
  appName: string;
  welcomeBonus: number;
  referralBonus: number;
  baseTapReward: number;
  baseEnergyCost: number;
  baseMaxEnergy: number;
  baseRechargeRate: number;
  baseMiningRatePerHour: number;
  rewardPerAd: number;
  maxRewardedAdsPerDay: number;
  adCooldownSeconds: number;
  dailyRewards: number[];
}

export interface AdminLog {
  id: string;
  adminId: string;
  action: string;
  targetUserId?: string;
  details: any;
  timestamp: number;
}

export interface DatabaseSchema {
  users: Record<string, UserRecord>;
  transactions: Record<string, TransactionRecord>;
  tasks: Record<string, TaskDefinition>;
  settings: {
    game: GameSettings;
  };
  admin: {
    logs: Record<string, AdminLog>;
  };
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Default initial tasks
const DEFAULT_TASKS: Record<string, TaskDefinition> = {
  'task-welcome': {
    id: 'task-welcome',
    title: 'Join Official News Channel',
    description: 'Subscribe to announcements & updates on Telegram',
    link: 'https://t.me/telegram',
    reward: 2500,
    type: 'telegram_channel',
    status: 'active',
  },
  'task-community': {
    id: 'task-community',
    title: 'Join Global Chat Group',
    description: 'Chat with other miners and get tips',
    link: 'https://t.me/telegram',
    reward: 2000,
    type: 'telegram_group',
    status: 'active',
  },
  'task-x-follow': {
    id: 'task-x-follow',
    title: 'Follow Official X (Twitter)',
    description: 'Stay updated with global airdrop notifications',
    link: 'https://twitter.com',
    reward: 3000,
    type: 'twitter',
    status: 'active',
  },
  'task-invite-3': {
    id: 'task-invite-3',
    title: 'Invite 3 Friends to Play',
    description: 'Bring 3 buddies into your mining squad',
    link: '',
    reward: 10000,
    type: 'referral',
    status: 'active',
    requiredCount: 3,
  },
};

const DEFAULT_SETTINGS: GameSettings = {
  appName: process.env.APP_NAME || 'Universal Telegram Mini App',
  welcomeBonus: Number(process.env.WELCOME_BONUS) || 1000,
  referralBonus: Number(process.env.REFERRAL_BONUS) || 2500,
  baseTapReward: 1,
  baseEnergyCost: 1,
  baseMaxEnergy: 1000,
  baseRechargeRate: 3,
  baseMiningRatePerHour: 50,
  rewardPerAd: Number(process.env.REWARD_PER_AD) || 1000,
  maxRewardedAdsPerDay: Number(process.env.MAX_REWARDED_ADS_PER_DAY) || 20,
  adCooldownSeconds: Number(process.env.AD_COOLDOWN_SECONDS) || 30,
  dailyRewards: [500, 1000, 2000, 5000, 10000, 20000, 50000],
};

class DatabaseService {
  private db: DatabaseSchema;
  private isSaving = false;

  constructor() {
    this.db = this.loadDatabase();
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          users: parsed.users || {},
          transactions: parsed.transactions || {},
          tasks: { ...DEFAULT_TASKS, ...(parsed.tasks || {}) },
          settings: {
            game: { ...DEFAULT_SETTINGS, ...(parsed.settings?.game || {}) },
          },
          admin: {
            logs: parsed.admin?.logs || {},
          },
        };
      }
    } catch (err) {
      console.warn('Could not read existing database.json, starting fresh:', err);
    }

    const initial: DatabaseSchema = {
      users: {},
      transactions: {},
      tasks: DEFAULT_TASKS,
      settings: {
        game: DEFAULT_SETTINGS,
      },
      admin: {
        logs: {},
      },
    };
    this.saveDatabase(initial);
    return initial;
  }

  private saveDatabase(data: DatabaseSchema): void {
    if (this.isSaving) return;
    this.isSaving = true;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving database:', err);
    } finally {
      this.isSaving = false;
    }
  }

  public getSettings(): GameSettings {
    return this.db.settings.game;
  }

  public updateSettings(newSettings: Partial<GameSettings>): GameSettings {
    this.db.settings.game = { ...this.db.settings.game, ...newSettings };
    this.saveDatabase(this.db);
    return this.db.settings.game;
  }

  public getUser(telegramId: string): UserRecord | null {
    const user = this.db.users[telegramId];
    if (!user) return null;
    // Calculate live energy regeneration before returning
    this.recalculateEnergy(user);
    return user;
  }

  public recalculateEnergy(user: UserRecord): void {
    const now = Date.now();
    const elapsedSeconds = Math.max(0, Math.floor((now - user.energy.lastUpdated) / 1000));
    if (elapsedSeconds > 0 && user.energy.current < user.energy.max) {
      const recovered = elapsedSeconds * user.energy.rechargeRate;
      user.energy.current = Math.min(user.energy.max, user.energy.current + recovered);
      user.energy.lastUpdated = now;
    }
  }

  public createUser(profile: UserProfile, referrerId?: string): UserRecord {
    const now = Date.now();
    const settings = this.getSettings();

    const newUser: UserRecord = {
      profile: {
        ...profile,
        createdAt: now,
        lastLoginAt: now,
      },
      balance: settings.welcomeBonus,
      energy: {
        current: settings.baseMaxEnergy,
        max: settings.baseMaxEnergy,
        rechargeRate: settings.baseRechargeRate,
        lastUpdated: now,
      },
      level: {
        current: 1,
        title: 'Bronze Miner',
        progress: 0,
      },
      mining: {
        coinsPerHour: settings.baseMiningRatePerHour,
        lastClaimedAt: now,
      },
      upgrades: {
        tapPower: 1,
        maxEnergy: 1,
        rechargeRate: 1,
        miningRate: 1,
        multiplier: 1,
      },
      referrals: {
        referrerId: referrerId || undefined,
        totalReferred: 0,
        totalEarned: 0,
        referredUsers: [],
      },
      rewards: {
        dailyStreak: {
          currentDay: 1,
          lastClaimDate: '',
        },
        ads: {
          lastWatchedAt: 0,
          todayCount: 0,
          todayDate: new Date().toISOString().split('T')[0],
        },
      },
      tasks: {},
      statistics: {
        totalTaps: 0,
        totalMined: 0,
        totalAdRewards: 0,
        totalTaskRewards: 0,
        totalReferralRewards: 0,
      },
      status: 'active',
    };

    this.db.users[profile.telegramId] = newUser;

    // Log welcome bonus transaction
    if (settings.welcomeBonus > 0) {
      this.createTransaction({
        userId: profile.telegramId,
        type: 'welcome_bonus',
        amount: settings.welcomeBonus,
        balanceBefore: 0,
        balanceAfter: settings.welcomeBonus,
        note: 'Welcome Bonus for joining',
      });
    }

    // Process Referral if valid
    if (referrerId && referrerId !== profile.telegramId && this.db.users[referrerId]) {
      const referrer = this.db.users[referrerId];
      if (referrer.status === 'active') {
        const bonus = settings.referralBonus;
        const balanceBefore = referrer.balance;
        referrer.balance += bonus;
        referrer.referrals.totalReferred += 1;
        referrer.referrals.totalEarned += bonus;
        referrer.statistics.totalReferralRewards += bonus;
        referrer.referrals.referredUsers.push({
          telegramId: profile.telegramId,
          username: profile.username || profile.firstName,
          bonusEarned: bonus,
          joinedAt: now,
        });

        this.createTransaction({
          userId: referrerId,
          type: 'referral_bonus',
          amount: bonus,
          balanceBefore,
          balanceAfter: referrer.balance,
          note: `Referral bonus for inviting @${profile.username || profile.telegramId}`,
        });
      }
    }

    this.saveDatabase(this.db);
    return newUser;
  }

  public saveUser(user: UserRecord): void {
    this.db.users[user.profile.telegramId] = user;
    this.saveDatabase(this.db);
  }

  public createTransaction(params: Omit<TransactionRecord, 'id' | 'timestamp'>): TransactionRecord {
    const id = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const record: TransactionRecord = {
      id,
      ...params,
      timestamp: Date.now(),
    };
    this.db.transactions[id] = record;
    this.saveDatabase(this.db);
    return record;
  }

  public getUserTransactions(userId: string, limit = 20): TransactionRecord[] {
    return Object.values(this.db.transactions)
      .filter((t) => t.userId === userId)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  public getAllTransactions(limit = 100): TransactionRecord[] {
    return Object.values(this.db.transactions)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  public getTasks(): TaskDefinition[] {
    return Object.values(this.db.tasks).filter((t) => t.status === 'active');
  }

  public getAllTasksAdmin(): TaskDefinition[] {
    return Object.values(this.db.tasks);
  }

  public saveTask(task: TaskDefinition): void {
    this.db.tasks[task.id] = task;
    this.saveDatabase(this.db);
  }

  public deleteTask(taskId: string): void {
    delete this.db.tasks[taskId];
    this.saveDatabase(this.db);
  }

  public logAdminAction(adminId: string, action: string, details: any, targetUserId?: string): void {
    const id = `log_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    this.db.admin.logs[id] = {
      id,
      adminId,
      action,
      targetUserId,
      details,
      timestamp: Date.now(),
    };
    this.saveDatabase(this.db);
  }

  public getAdminLogs(limit = 50): AdminLog[] {
    return Object.values(this.db.admin.logs)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
  }

  public getLeaderboard(limit = 50) {
    const allUsers = Object.values(this.db.users).filter((u) => u.status !== 'banned');
    const byBalance = [...allUsers]
      .sort((a, b) => b.balance - a.balance)
      .slice(0, limit)
      .map((u, idx) => ({
        rank: idx + 1,
        telegramId: u.profile.telegramId,
        firstName: u.profile.firstName,
        username: u.profile.username,
        balance: u.balance,
        level: u.level.current,
        totalReferred: u.referrals.totalReferred,
      }));

    return byBalance;
  }

  public getAllUsersAdmin(): UserRecord[] {
    return Object.values(this.db.users);
  }

  public getStats() {
    const users = Object.values(this.db.users);
    const transactions = Object.values(this.db.transactions);
    const now = Date.now();
    const oneDayAgo = now - 24 * 60 * 60 * 1000;

    const totalUsers = users.length;
    const activeUsers = users.filter((u) => u.status === 'active').length;
    const bannedUsers = users.filter((u) => u.status === 'banned').length;
    const newUsers24h = users.filter((u) => u.profile.createdAt >= oneDayAgo).length;
    const totalBalance = users.reduce((acc, u) => acc + (u.balance || 0), 0);

    const totalAdRewards = transactions
      .filter((t) => t.type === 'ad_reward')
      .reduce((acc, t) => acc + t.amount, 0);

    const totalReferralRewards = transactions
      .filter((t) => t.type === 'referral_bonus')
      .reduce((acc, t) => acc + t.amount, 0);

    return {
      totalUsers,
      activeUsers,
      bannedUsers,
      newUsers24h,
      totalBalance,
      totalAdRewards,
      totalReferralRewards,
      totalTransactions: transactions.length,
    };
  }
}

export const dbService = new DatabaseService();
