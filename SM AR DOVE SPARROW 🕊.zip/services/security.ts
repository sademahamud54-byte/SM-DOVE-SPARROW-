import { UserRecord, dbService } from './firebase.ts';

interface TapVerificationInput {
  user: UserRecord;
  taps: number;
  clientTimestamp: number;
  clientCoins?: number;
}

interface TapVerificationResult {
  allowed: boolean;
  reason?: string;
  coinsGained: number;
  energyUsed: number;
}

export class SecurityService {
  private lastTapTimestamps: Map<string, number> = new Map();
  private tapFrequencyMap: Map<string, { count: number; windowStart: number }> = new Map();

  /**
   * Validates tap operation against server-authoritative energy, upgrade multipliers, and anti-cheat constraints.
   */
  public validateTap(input: TapVerificationInput): TapVerificationResult {
    const { user, taps, clientTimestamp } = input;
    const settings = dbService.getSettings();

    // Check account ban/suspension
    if (user.status === 'banned') {
      return { allowed: false, reason: 'Account is banned.', coinsGained: 0, energyUsed: 0 };
    }
    if (user.status === 'suspended') {
      return { allowed: false, reason: 'Account is temporarily suspended.', coinsGained: 0, energyUsed: 0 };
    }

    // 1. Sanitize tap count
    if (!taps || taps <= 0 || !Number.isInteger(taps)) {
      return { allowed: false, reason: 'Invalid tap count.', coinsGained: 0, energyUsed: 0 };
    }

    // 2. Max taps per batch constraint (e.g. max 100 taps in a single sync batch)
    if (taps > 100) {
      return { allowed: false, reason: 'Tap batch exceeds limit (max 100 per sync).', coinsGained: 0, energyUsed: 0 };
    }

    // 3. Frequency rate limiting
    const now = Date.now();
    const userId = user.profile.telegramId;
    const lastTap = this.lastTapTimestamps.get(userId) || 0;
    this.lastTapTimestamps.set(userId, now);

    const freq = this.tapFrequencyMap.get(userId) || { count: 0, windowStart: now };
    if (now - freq.windowStart > 1000) {
      freq.count = taps;
      freq.windowStart = now;
    } else {
      freq.count += taps;
    }
    this.tapFrequencyMap.set(userId, freq);

    // If more than 35 taps within a 1-second rolling window -> suspicious autoclicker
    if (freq.count > 35) {
      console.warn(`[AntiCheat] Suspicious tap frequency for user ${userId}: ${freq.count} taps/sec`);
      dbService.logAdminAction(
        'SYSTEM_ANTICHEAT',
        'SUSPICIOUS_TAP_RATE',
        { tapsPerSecond: freq.count, requestedTaps: taps },
        userId
      );
      return {
        allowed: false,
        reason: 'Too many rapid taps detected. Please tap at normal human speed.',
        coinsGained: 0,
        energyUsed: 0,
      };
    }

    // 4. Calculate server-side energy regeneration
    dbService.recalculateEnergy(user);

    // 5. Energy validation
    const energyPerTap = settings.baseEnergyCost;
    const requiredEnergy = taps * energyPerTap;

    // How many taps can the user actually afford?
    const affordableTaps = Math.min(taps, Math.floor(user.energy.current / energyPerTap));

    if (affordableTaps <= 0) {
      return {
        allowed: false,
        reason: 'Energy depleted! Wait for energy to regenerate.',
        coinsGained: 0,
        energyUsed: 0,
      };
    }

    // 6. Calculate coin earnings based on dynamic tap points and upgrades
    const tapPowerLevel = user.upgrades?.tapPower || 1;
    const multiplierLevel = user.upgrades?.multiplier || 1;
    const tapMultiplier = 1 + (multiplierLevel - 1) * 0.2; // +20% per multiplier level

    // Max allowable coins per tap: maximum single tap can be 25 plus upgrade bonuses
    const maxCoinsPerTap = (25 + (tapPowerLevel - 1) * 5) * tapMultiplier;
    const maxAllowableCoins = Math.round(affordableTaps * maxCoinsPerTap);

    let coinsGained: number;
    if (typeof input.clientCoins === 'number' && input.clientCoins > 0 && input.clientCoins <= maxAllowableCoins) {
      coinsGained = Math.round(input.clientCoins);
    } else {
      // Default dynamic reward calculation
      const avgRewardPerTap = 8 + (tapPowerLevel - 1) * 2;
      coinsGained = Math.round(affordableTaps * avgRewardPerTap * tapMultiplier);
    }

    const energyUsed = affordableTaps * energyPerTap;

    return {
      allowed: true,
      coinsGained,
      energyUsed,
    };
  }

  /**
   * Anti-Cheat check for Referrals
   */
  public validateReferral(referrerId: string, newUserId: string): { valid: boolean; reason?: string } {
    if (referrerId === newUserId) {
      return { valid: false, reason: 'Self-referral is prohibited.' };
    }
    const referrer = dbService.getUser(referrerId);
    if (!referrer) {
      return { valid: false, reason: 'Referrer account not found.' };
    }
    if (referrer.status === 'banned') {
      return { valid: false, reason: 'Referrer is banned.' };
    }
    const alreadyReferred = referrer.referrals.referredUsers.some((u) => u.telegramId === newUserId);
    if (alreadyReferred) {
      return { valid: false, reason: 'User has already been referred.' };
    }
    return { valid: true };
  }
}

export const securityService = new SecurityService();
