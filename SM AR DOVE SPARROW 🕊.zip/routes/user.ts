import { Router } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.ts';
import { dbService, UserUpgrades } from '../services/firebase.ts';
import { securityService } from '../services/security.ts';

const router = Router();

// Calculate upgrade costs and effects
const UPGRADE_CONFIG = {
  tapPower: {
    baseCost: 100,
    costMultiplier: 1.8,
    maxLevel: 25,
    name: 'Tap Power',
    description: '+1 coin per tap',
  },
  maxEnergy: {
    baseCost: 150,
    costMultiplier: 1.6,
    maxLevel: 25,
    name: 'Energy Tank',
    description: '+500 maximum energy capacity',
  },
  rechargeRate: {
    baseCost: 200,
    costMultiplier: 2.0,
    maxLevel: 20,
    name: 'Turbo Charger',
    description: '+2 energy recovered per second',
  },
  miningRate: {
    baseCost: 250,
    costMultiplier: 2.2,
    maxLevel: 30,
    name: 'Mining Hardware',
    description: '+100 passive coins per hour',
  },
  multiplier: {
    baseCost: 500,
    costMultiplier: 2.5,
    maxLevel: 15,
    name: 'Yield Booster',
    description: '+20% global coin multiplier',
  },
};

export function getUpgradeCost(type: keyof UserUpgrades, currentLevel: number): number {
  const conf = UPGRADE_CONFIG[type];
  if (!conf) return 999999;
  return Math.round(conf.baseCost * Math.pow(conf.costMultiplier, currentLevel - 1));
}

/**
 * GET /api/me — Returns current authenticated user state
 */
router.get('/me', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  dbService.recalculateEnergy(user);
  res.json({
    user,
    isAdmin: req.isAdmin || false,
    serverTime: Date.now(),
  });
});

/**
 * POST /api/tap — Validates taps against server energy and anti-cheat
 */
router.post('/tap', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const taps = Number(req.body.taps || 1);
  const clientTimestamp = Number(req.body.timestamp || Date.now());
  const clientCoins = typeof req.body.coins === 'number' ? Number(req.body.coins) : undefined;

  const validation = securityService.validateTap({
    user,
    taps,
    clientTimestamp,
    clientCoins,
  });

  if (!validation.allowed) {
    res.status(400).json({ error: validation.reason });
    return;
  }

  const balanceBefore = user.balance;
  user.balance += validation.coinsGained;
  user.energy.current = Math.max(0, user.energy.current - validation.energyUsed);
  user.energy.lastUpdated = Date.now();
  user.statistics.totalTaps += taps;

  // Level Progression: Level = floor(cbrt(balance / 500)) + 1
  const newLevel = Math.max(1, Math.floor(Math.cbrt(user.balance / 500)) + 1);
  if (newLevel !== user.level.current) {
    user.level.current = newLevel;
    const titles = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster', 'Legendary'];
    user.level.title = `${titles[Math.min(titles.length - 1, newLevel - 1)]} Miner`;
  }

  // Periodic transaction logging for tap batches (prevent flooding database on single taps)
  if (validation.coinsGained >= 20 || user.statistics.totalTaps % 50 === 0) {
    dbService.createTransaction({
      userId: user.profile.telegramId,
      type: 'tap',
      amount: validation.coinsGained,
      balanceBefore,
      balanceAfter: user.balance,
      note: `Earned from ${taps} taps`,
    });
  }

  dbService.saveUser(user);

  res.json({
    success: true,
    balance: user.balance,
    energy: user.energy,
    level: user.level,
    coinsGained: validation.coinsGained,
  });
});

/**
 * POST /api/claim-mining — Claims offline passive mining income
 */
router.post('/claim-mining', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const now = Date.now();
  const lastClaimed = user.mining.lastClaimedAt || user.profile.createdAt;
  const elapsedHours = (now - lastClaimed) / (1000 * 60 * 60);

  // Maximum 24 hours of accumulated passive earnings without opening the app
  const cappedHours = Math.min(24, Math.max(0, elapsedHours));
  const ratePerHour = user.mining.coinsPerHour || 50;
  const earned = Math.floor(cappedHours * ratePerHour);

  if (earned <= 0) {
    res.status(400).json({ error: 'No mining rewards accumulated yet. Please check back later.' });
    return;
  }

  const balanceBefore = user.balance;
  user.balance += earned;
  user.mining.lastClaimedAt = now;
  user.statistics.totalMined += earned;

  dbService.createTransaction({
    userId: user.profile.telegramId,
    type: 'mining',
    amount: earned,
    balanceBefore,
    balanceAfter: user.balance,
    note: `Passive mining claim for ${cappedHours.toFixed(2)} hours`,
  });

  dbService.saveUser(user);

  res.json({
    success: true,
    claimedAmount: earned,
    balance: user.balance,
    lastClaimedAt: now,
  });
});

/**
 * POST /api/upgrade — Purchases upgrades for tap power, energy, recharge, or mining
 */
router.post('/upgrade', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const type = req.body.type as keyof UserUpgrades;

  if (!UPGRADE_CONFIG[type]) {
    res.status(400).json({ error: 'Invalid upgrade category.' });
    return;
  }

  const conf = UPGRADE_CONFIG[type];
  const currentLevel = user.upgrades[type] || 1;

  if (currentLevel >= conf.maxLevel) {
    res.status(400).json({ error: `This upgrade has reached its maximum level (${conf.maxLevel}).` });
    return;
  }

  const cost = getUpgradeCost(type, currentLevel);
  if (user.balance < cost) {
    res.status(400).json({ error: `Insufficient balance. Need ${cost.toLocaleString()} coins.` });
    return;
  }

  // Deduct cost and apply upgrade effects
  const balanceBefore = user.balance;
  user.balance -= cost;
  user.upgrades[type] = currentLevel + 1;

  // Apply real-time effects to stats
  if (type === 'maxEnergy') {
    user.energy.max += 500;
  } else if (type === 'rechargeRate') {
    user.energy.rechargeRate += 2;
  } else if (type === 'miningRate') {
    user.mining.coinsPerHour += 100;
  }

  dbService.createTransaction({
    userId: user.profile.telegramId,
    type: 'upgrade',
    amount: -cost,
    balanceBefore,
    balanceAfter: user.balance,
    note: `Upgraded ${conf.name} to Level ${currentLevel + 1}`,
  });

  dbService.saveUser(user);

  res.json({
    success: true,
    upgrades: user.upgrades,
    balance: user.balance,
    energy: user.energy,
    mining: user.mining,
    costPaid: cost,
  });
});

/**
 * GET /api/leaderboard — Top miners rankings
 */
router.get('/leaderboard', authMiddleware, (req: AuthenticatedRequest, res) => {
  const leaderboard = dbService.getLeaderboard(50);
  const userRank = leaderboard.findIndex((item) => item.telegramId === req.telegramId) + 1;

  res.json({
    leaderboard,
    userRank: userRank > 0 ? userRank : null,
  });
});

/**
 * GET /api/transactions — User's recent transaction log
 */
router.get('/transactions', authMiddleware, (req: AuthenticatedRequest, res) => {
  const txs = dbService.getUserTransactions(req.telegramId!, 30);
  res.json({ transactions: txs });
});

export default router;
