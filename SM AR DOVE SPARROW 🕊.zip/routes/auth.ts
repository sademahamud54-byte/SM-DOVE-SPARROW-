import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.ts';
import { dbService } from '../services/firebase.ts';

const router = Router();

// Load master configuration file
let appConfig: any = {};
try {
  const configPath = path.resolve(process.cwd(), 'config', 'app-config.json');
  if (fs.existsSync(configPath)) {
    appConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  }
} catch (e) {
  console.warn('Could not parse config/app-config.json:', e);
}

/**
 * Public configuration endpoint for frontend (NEVER returns secrets!)
 */
router.get('/config/public', (req, res) => {
  const settings = dbService.getSettings();

  const botUsername = (
    process.env.BOT_USERNAME ||
    appConfig.telegram?.botUsername ||
    'SMDOVESPARROW_bot'
  ).replace(/^@/, '');

  res.json({
    appName: process.env.APP_NAME || appConfig.app?.name || 'SM DOVE SPARROW',
    botName: process.env.BOT_NAME || appConfig.telegram?.botName || 'SM DOVE SPARROW 🕊️',
    botUsername,
    adminContact: {
      username: process.env.ADMIN_USERNAME || appConfig.admin?.username || '@sadimahomud247',
      phone: process.env.ADMIN_PHONE || appConfig.admin?.phone || '01915921501',
      email: process.env.ADMIN_EMAIL || appConfig.admin?.email || 'YOUR_ADMIN_EMAIL',
    },
    monetag: {
      zone1: process.env.MONETAG_ZONE_1 || appConfig.monetag?.zone1 || '11924593',
      zone2: process.env.MONETAG_ZONE_2 || appConfig.monetag?.zone2 || '11924529',
      zone3: process.env.MONETAG_ZONE_3 || appConfig.monetag?.zone3 || '11924571',
      zone4: process.env.MONETAG_ZONE_4 || appConfig.monetag?.zone4 || '11949016',
    },
    game: {
      welcomeBonus: settings.welcomeBonus || appConfig.game?.welcomeBonus || 1000,
      referralBonus: settings.referralBonus || appConfig.game?.referralBonus || 2500,
      baseTapReward: settings.baseTapReward || 1,
      baseMaxEnergy: settings.baseMaxEnergy || 1000,
      baseMiningRatePerHour: settings.baseMiningRatePerHour || 50,
      rewardPerAd: settings.rewardPerAd || appConfig.monetag?.rewardPerAd || 1000,
      maxRewardedAdsPerDay: settings.maxRewardedAdsPerDay || appConfig.monetag?.maxRewardedAdsPerDay || 20,
      adCooldownSeconds: settings.adCooldownSeconds || appConfig.monetag?.adCooldownSeconds || 30,
      dailyRewards: settings.dailyRewards || [500, 1000, 2000, 5000, 10000, 20000, 50000],
    },
    isSimulatedBot:
      !process.env.BOT_TOKEN ||
      process.env.BOT_TOKEN.includes('YOUR_NEW_BOT_TOKEN') ||
      process.env.BOT_TOKEN.includes('[CHANGE_ME_'),
  });
});

/**
 * Auth endpoint: verifies Telegram initData and returns user payload
 */
router.post('/auth', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  res.json({
    user,
    isAdmin: req.isAdmin || false,
    serverTime: Date.now(),
  });
});

export default router;
