import { Router } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.ts';
import { dbService } from '../services/firebase.ts';

const router = Router();

/**
 * GET /api/referrals — Current user's referral link, count, and earnings
 */
router.get('/', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const settings = dbService.getSettings();
  const botUsername = process.env.BOT_USERNAME || 'MiningBot';

  const referralLink = `https://t.me/${botUsername}?start=ref_${user.profile.telegramId}`;

  res.json({
    referralLink,
    referralBonus: settings.referralBonus,
    totalReferred: user.referrals.totalReferred,
    totalEarned: user.referrals.totalEarned,
    referredUsers: user.referrals.referredUsers.slice(-20).reverse(),
  });
});

export default router;
