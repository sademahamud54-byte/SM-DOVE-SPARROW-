import { Router } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.ts';
import { dbService } from '../services/firebase.ts';
import { adService } from '../services/ads.ts';

const router = Router();

/**
 * GET /api/tasks — Active tasks list with user completion statuses
 */
router.get('/tasks', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const tasks = dbService.getTasks();

  const formattedTasks = tasks.map((task) => {
    const userTask = user.tasks[task.id];
    let isEligible = true;

    // Check custom requirements
    if (task.type === 'referral' && task.requiredCount) {
      isEligible = user.referrals.totalReferred >= task.requiredCount;
    }

    return {
      ...task,
      completed: !!userTask?.completed,
      claimedAt: userTask?.claimedAt || null,
      isEligible,
    };
  });

  res.json({ tasks: formattedTasks });
});

/**
 * POST /api/task/claim — Verify and claim task reward
 */
router.post('/task/claim', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const taskId = req.body.taskId as string;

  const tasks = dbService.getTasks();
  const task = tasks.find((t) => t.id === taskId);

  if (!task) {
    res.status(404).json({ error: 'Task not found or no longer active.' });
    return;
  }

  if (user.tasks[taskId]?.completed) {
    res.status(400).json({ error: 'You have already completed and claimed this task.' });
    return;
  }

  // Verification logic based on task type
  if (task.type === 'referral' && task.requiredCount) {
    if (user.referrals.totalReferred < task.requiredCount) {
      res.status(400).json({
        error: `Requirement not met: You need ${task.requiredCount} referrals. Currently you have ${user.referrals.totalReferred}.`,
      });
      return;
    }
  }

  // Mark task as completed
  const now = Date.now();
  user.tasks[taskId] = { completed: true, claimedAt: now };

  const balanceBefore = user.balance;
  user.balance += task.reward;
  user.statistics.totalTaskRewards += task.reward;

  dbService.createTransaction({
    userId: user.profile.telegramId,
    type: 'task_reward',
    amount: task.reward,
    balanceBefore,
    balanceAfter: user.balance,
    note: `Completed task: ${task.title}`,
  });

  dbService.saveUser(user);

  res.json({
    success: true,
    reward: task.reward,
    balance: user.balance,
    taskId,
  });
});

/**
 * POST /api/daily-reward/claim — Claims daily streak bonus
 */
router.post('/daily-reward/claim', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const settings = dbService.getSettings();
  const todayStr = new Date().toISOString().split('T')[0];

  const currentStreak = user.rewards?.dailyStreak || { currentDay: 1, lastClaimDate: '' };

  if (currentStreak.lastClaimDate === todayStr) {
    res.status(400).json({ error: "You have already claimed today's reward! Come back tomorrow." });
    return;
  }

  // Check if yesterday was claimed to continue streak, or reset to 1
  let nextDay = 1;
  if (currentStreak.lastClaimDate) {
    const lastDate = new Date(currentStreak.lastClaimDate);
    const today = new Date(todayStr);
    const diffDays = Math.round((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      nextDay = (currentStreak.currentDay % 7) + 1;
    } else {
      nextDay = 1; // Streak broken
    }
  }

  const rewardsSchedule = settings.dailyRewards || [500, 1000, 2000, 5000, 10000, 20000, 50000];
  const rewardAmount = rewardsSchedule[nextDay - 1] || 1000;

  const balanceBefore = user.balance;
  user.balance += rewardAmount;
  user.rewards.dailyStreak = {
    currentDay: nextDay,
    lastClaimDate: todayStr,
  };

  dbService.createTransaction({
    userId: user.profile.telegramId,
    type: 'daily_reward',
    amount: rewardAmount,
    balanceBefore,
    balanceAfter: user.balance,
    note: `Day ${nextDay} Daily Login Reward`,
  });

  dbService.saveUser(user);

  res.json({
    success: true,
    day: nextDay,
    reward: rewardAmount,
    balance: user.balance,
    dailyStreak: user.rewards.dailyStreak,
  });
});

/**
 * POST /api/ad/reward — Validates Monetag ad completion and awards coins
 */
router.post('/ad/reward', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const zoneId = req.body.zoneId as string;

  const result = adService.verifyAndReward(user, zoneId);

  if (!result.success) {
    res.status(400).json({ error: result.message, ...result });
    return;
  }

  res.json({
    success: true,
    message: result.message,
    reward: result.coinsAwarded,
    balance: user.balance,
    remainingAdsToday: result.remainingAdsToday,
    nextAvailableInSeconds: result.nextAvailableInSeconds,
  });
});

export default router;
