import { Router } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.ts';
import { adminMiddleware } from '../middleware/admin.ts';
import { dbService, TaskDefinition } from '../services/firebase.ts';
import { telegramService } from '../services/telegram.ts';

const router = Router();

// Apply auth and admin protection to all routes in this file
router.use(authMiddleware);
router.use(adminMiddleware);

/**
 * GET /api/admin/dashboard — Global statistics & analytics
 */
router.get('/dashboard', (req: AuthenticatedRequest, res) => {
  const stats = dbService.getStats();
  const settings = dbService.getSettings();
  const recentLogs = dbService.getAdminLogs(10);

  res.json({
    stats,
    settings,
    recentLogs,
    adminId: req.telegramId,
    botConfigured: telegramService.isBotTokenConfigured(),
  });
});

/**
 * GET /api/admin/users — List and search users
 */
router.get('/users', (req, res) => {
  const query = (req.query.q as string)?.toLowerCase() || '';
  const allUsers = dbService.getAllUsersAdmin();

  let filtered = allUsers;
  if (query) {
    filtered = allUsers.filter(
      (u) =>
        u.profile.telegramId.includes(query) ||
        u.profile.firstName?.toLowerCase().includes(query) ||
        u.profile.username?.toLowerCase().includes(query)
    );
  }

  res.json({
    total: filtered.length,
    users: filtered.slice(0, 100).map((u) => ({
      telegramId: u.profile.telegramId,
      name: `${u.profile.firstName || ''} ${u.profile.lastName || ''}`.trim(),
      username: u.profile.username,
      balance: u.balance,
      level: u.level.current,
      status: u.status,
      totalReferred: u.referrals.totalReferred,
      createdAt: u.profile.createdAt,
      lastLoginAt: u.profile.lastLoginAt,
    })),
  });
});

/**
 * GET /api/admin/users/:id — Detailed user record with transactions
 */
router.get('/users/:id', (req, res) => {
  const user = dbService.getUser(req.params.id);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  const transactions = dbService.getUserTransactions(req.params.id, 25);
  res.json({ user, transactions });
});

/**
 * POST /api/admin/user/ban — Bans user account
 */
router.post('/user/ban', (req: AuthenticatedRequest, res) => {
  const targetId = req.body.telegramId as string;
  const reason = req.body.reason || 'Banned by Administrator';

  const user = dbService.getUser(targetId);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  user.status = 'banned';
  dbService.saveUser(user);

  dbService.logAdminAction(
    req.telegramId!,
    'BAN_USER',
    { reason, targetUser: user.profile.username || targetId },
    targetId
  );

  res.json({ success: true, message: `User ${targetId} has been banned.` });
});

/**
 * POST /api/admin/user/unban — Unbans user account
 */
router.post('/user/unban', (req: AuthenticatedRequest, res) => {
  const targetId = req.body.telegramId as string;

  const user = dbService.getUser(targetId);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  user.status = 'active';
  dbService.saveUser(user);

  dbService.logAdminAction(
    req.telegramId!,
    'UNBAN_USER',
    { targetUser: user.profile.username || targetId },
    targetId
  );

  res.json({ success: true, message: `User ${targetId} has been restored to active status.` });
});

/**
 * POST /api/admin/balance — Adjust user balance (+/-)
 */
router.post('/balance', (req: AuthenticatedRequest, res) => {
  const targetId = req.body.telegramId as string;
  const amount = Number(req.body.amount);
  const note = req.body.note || 'Admin adjustment';

  if (isNaN(amount) || amount === 0) {
    res.status(400).json({ error: 'Invalid adjustment amount.' });
    return;
  }

  const user = dbService.getUser(targetId);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const balanceBefore = user.balance;
  user.balance = Math.max(0, user.balance + amount);

  dbService.createTransaction({
    userId: targetId,
    type: 'admin_adjustment',
    amount,
    balanceBefore,
    balanceAfter: user.balance,
    note: `${note} (by Admin ${req.telegramId})`,
  });

  dbService.saveUser(user);

  dbService.logAdminAction(
    req.telegramId!,
    'ADJUST_BALANCE',
    { amount, balanceBefore, balanceAfter: user.balance, note },
    targetId
  );

  res.json({
    success: true,
    targetId,
    newBalance: user.balance,
  });
});

/**
 * GET /api/admin/settings — View current game settings
 */
router.get('/settings', (req, res) => {
  res.json({ settings: dbService.getSettings() });
});

/**
 * POST /api/admin/settings — Update game configuration
 */
router.post('/settings', (req: AuthenticatedRequest, res) => {
  const updates = req.body.settings;
  if (!updates || typeof updates !== 'object') {
    res.status(400).json({ error: 'Invalid settings payload.' });
    return;
  }

  const updated = dbService.updateSettings(updates);

  dbService.logAdminAction(
    req.telegramId!,
    'UPDATE_SETTINGS',
    { updates },
    undefined
  );

  res.json({ success: true, settings: updated });
});

/**
 * POST /api/admin/broadcast — Broadcast message to active users via Telegram Bot
 */
router.post('/broadcast', async (req: AuthenticatedRequest, res) => {
  const message = req.body.message as string;
  if (!message || message.trim().length === 0) {
    res.status(400).json({ error: 'Broadcast message cannot be empty.' });
    return;
  }

  const allUsers = dbService.getAllUsersAdmin().filter((u) => u.status === 'active');
  const userIds = allUsers.map((u) => u.profile.telegramId);

  const result = await telegramService.broadcast(userIds, message);

  dbService.logAdminAction(
    req.telegramId!,
    'BROADCAST_MESSAGE',
    {
      messageLength: message.length,
      successCount: result.successCount,
      failureCount: result.failureCount,
    }
  );

  res.json({
    success: true,
    totalTargeted: userIds.length,
    ...result,
  });
});

/**
 * GET /api/admin/logs — Audit logs
 */
router.get('/logs', (req, res) => {
  const logs = dbService.getAdminLogs(100);
  res.json({ logs });
});

/**
 * GET /api/admin/tasks — Manage tasks
 */
router.get('/tasks', (req, res) => {
  const tasks = dbService.getAllTasksAdmin();
  res.json({ tasks });
});

/**
 * POST /api/admin/tasks — Create or update task
 */
router.post('/tasks', (req: AuthenticatedRequest, res) => {
  const task = req.body.task as TaskDefinition;
  if (!task || !task.title || !task.reward) {
    res.status(400).json({ error: 'Invalid task definition.' });
    return;
  }

  if (!task.id) {
    task.id = `task-${Date.now()}`;
  }

  dbService.saveTask(task);

  dbService.logAdminAction(req.telegramId!, 'SAVE_TASK', { taskId: task.id, title: task.title });

  res.json({ success: true, task });
});

/**
 * POST /api/admin/tasks/delete — Delete task
 */
router.post('/tasks/delete', (req: AuthenticatedRequest, res) => {
  const taskId = req.body.taskId as string;
  if (!taskId) {
    res.status(400).json({ error: 'Task ID required.' });
    return;
  }

  dbService.deleteTask(taskId);
  dbService.logAdminAction(req.telegramId!, 'DELETE_TASK', { taskId });

  res.json({ success: true });
});

export default router;
