import { Response, NextFunction } from 'express';
import { AuthenticatedRequest, isConfiguredAdmin } from './auth.ts';
import { dbService } from '../services/firebase.ts';

export function adminMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.telegramId || !isConfiguredAdmin(req.telegramId)) {
    console.warn(`[SECURITY] Unauthorized admin access attempt by Telegram ID: ${req.telegramId}`);
    dbService.logAdminAction(
      'UNAUTHORIZED_ATTEMPT',
      'ADMIN_ROUTE_ACCESS_DENIED',
      { attemptedPath: req.originalUrl, ip: req.ip },
      req.telegramId
    );
    res.status(403).json({
      error: 'Access Denied: You do not have administrator permissions.',
    });
    return;
  }

  next();
}
