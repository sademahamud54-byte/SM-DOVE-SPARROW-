import { Request, Response, NextFunction } from 'express';
import { telegramService } from '../services/telegram.ts';
import { dbService, UserRecord } from '../services/firebase.ts';

export interface AuthenticatedRequest extends Request {
  user?: UserRecord;
  telegramId?: string;
  isAdmin?: boolean;
}

export function isConfiguredAdmin(telegramId?: string): boolean {
  if (!telegramId) return false;
  const configured = process.env.ADMIN_TELEGRAM_ID;
  if (configured && !configured.includes('[CHANGE_ME_')) {
    return telegramId === configured;
  }
  // Default to prompt example admin ID: 8801424830
  return telegramId === '8801424830';
}

export function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  // Check for Telegram WebApp initData in headers
  const authHeader = req.headers['authorization'];
  const initDataHeader = req.headers['x-telegram-init-data'] as string;
  const initDataQuery = req.query.initData as string;

  let rawInitData = initDataHeader || initDataQuery;
  if (!rawInitData && authHeader && authHeader.startsWith('Bearer ')) {
    rawInitData = authHeader.substring(7);
  }

  // Also support simulator header for testing in browser / AI Studio
  const simUserId = req.headers['x-telegram-sim-user-id'] as string;
  const simUsername = req.headers['x-telegram-sim-username'] as string;

  if (!rawInitData && simUserId) {
    // Simulator mode
    let user = dbService.getUser(simUserId);
    if (!user) {
      user = dbService.createUser({
        telegramId: simUserId,
        firstName: simUsername || `User_${simUserId}`,
        username: simUsername,
        createdAt: Date.now(),
        lastLoginAt: Date.now(),
      });
    }
    req.user = user;
    req.telegramId = simUserId;
    req.isAdmin = isConfiguredAdmin(simUserId);
    return next();
  }

  if (!rawInitData) {
    res.status(401).json({
      error: 'Authentication failed: Missing Telegram initData. Please reopen the Mini App from Telegram.',
    });
    return;
  }

  const verification = telegramService.verifyInitData(rawInitData);

  if (!verification.isValid || !verification.user) {
    res.status(401).json({
      error: `Authentication failed: ${verification.error || 'Invalid signature'}. Please reopen from Telegram.`,
    });
    return;
  }

  const tgUser = verification.user;
  const telegramId = tgUser.id.toString();

  // Find or create user
  let user = dbService.getUser(telegramId);
  if (!user) {
    let referrerId: string | undefined = undefined;
    if (verification.startParam && verification.startParam.startsWith('ref_')) {
      referrerId = verification.startParam.replace('ref_', '');
    }
    user = dbService.createUser(
      {
        telegramId,
        firstName: tgUser.first_name,
        lastName: tgUser.last_name,
        username: tgUser.username,
        languageCode: tgUser.language_code,
        createdAt: Date.now(),
        lastLoginAt: Date.now(),
      },
      referrerId
    );
  } else {
    // Update last login
    user.profile.lastLoginAt = Date.now();
    if (tgUser.first_name) user.profile.firstName = tgUser.first_name;
    if (tgUser.username) user.profile.username = tgUser.username;
    dbService.saveUser(user);
  }

  if (user.status === 'banned') {
    res.status(403).json({
      error: 'Your account has been banned due to violation of service terms.',
      status: 'banned',
    });
    return;
  }

  req.user = user;
  req.telegramId = telegramId;
  req.isAdmin = isConfiguredAdmin(telegramId);

  next();
}
