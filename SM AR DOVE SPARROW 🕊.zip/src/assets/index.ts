import botBackground from './images/bot_background.jpg';
import tapRobotNormal from './images/tap_robot_normal.jpg';
import tapRobotWinking from './images/tap_robot_winking.jpg';

export {
  botBackground,
  tapRobotNormal,
  tapRobotWinking,
};
