import React, { useState, useEffect } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { AdminStats } from '../types.ts';
import {
  Shield,
  Users,
  Settings,
  Send,
  Sliders,
  DollarSign,
  Ban,
  CheckCircle,
  FileText,
  AlertTriangle,
  RefreshCw,
  Search,
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { simulatedTelegramId, triggerHaptic, refreshUser } = useTelegram();
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'settings' | 'broadcast' | 'logs'>('stats');

  // Dashboard Stats
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  // Users List
  const [usersList, setUsersList] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>('');
  const [adjustNote, setAdjustNote] = useState<string>('');

  // Game Settings
  const [gameSettings, setGameSettings] = useState<any>({});
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Broadcast
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [broadcastResult, setBroadcastResult] = useState<any | null>(null);
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  // Logs
  const [logs, setLogs] = useState<any[]>([]);

  // Notifications
  const [feedback, setFeedback] = useState<string | null>(null);

  const getHeaders = () => {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    const tg = window.Telegram?.WebApp;
    if (tg && tg.initData) {
      headers['x-telegram-init-data'] = tg.initData;
    } else {
      headers['x-telegram-sim-user-id'] = simulatedTelegramId;
    }
    return headers;
  };

  const fetchDashboard = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/dashboard', { headers: getHeaders() });
      const data = await res.json();
      if (res.ok) {
        setStats(data.stats);
        setGameSettings(data.settings);
        setLogs(data.recentLogs || []);
      } else {
        setFeedback(data.error || 'Failed to load dashboard');
      }
    } catch (err) {
      console.error('Admin fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch(`/api/admin/users?q=${encodeURIComponent(searchQuery)}`, {
        headers: getHeaders(),
      });
      const data = await res.json();
      if (res.ok) {
        setUsersList(data.users || []);
      }
    } catch (err) {
      console.error('Fetch users error:', err);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/admin/logs', { headers: getHeaders() });
      const data = await res.json();
      if (res.ok) {
        setLogs(data.logs || []);
      }
    } catch (err) {
      console.error('Fetch logs error:', err);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, [simulatedTelegramId]);

  useEffect(() => {
    if (activeTab === 'users') fetchUsers();
    if (activeTab === 'logs') fetchLogs();
  }, [activeTab, searchQuery]);

  // Ban/Unban user
  const handleToggleBan = async (user: any) => {
    triggerHaptic('medium');
    const isBanned = user.status === 'banned';
    const endpoint = isBanned ? '/api/admin/user/unban' : '/api/admin/user/ban';

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ telegramId: user.telegramId, reason: 'Admin panel manual action' }),
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback(data.message);
        fetchUsers();
        if (selectedUser?.telegramId === user.telegramId) {
          setSelectedUser((prev: any) => ({ ...prev, status: isBanned ? 'active' : 'banned' }));
        }
      } else {
        setFeedback(data.error);
      }
    } catch (e) {
      setFeedback('Action failed');
    }
    setTimeout(() => setFeedback(null), 3000);
  };

  // Adjust Balance
  const handleAdjustBalance = async () => {
    if (!selectedUser || !adjustAmount) return;
    triggerHaptic('medium');

    try {
      const res = await fetch('/api/admin/balance', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          telegramId: selectedUser.telegramId,
          amount: Number(adjustAmount),
          note: adjustNote || 'Admin manual balance adjustment',
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setFeedback(`Adjusted balance for ${selectedUser.telegramId}: ${data.newBalance} coins`);
        setAdjustAmount('');
        setAdjustNote('');
        fetchUsers();
        refreshUser();
      } else {
        setFeedback(data.error);
      }
    } catch (e) {
      setFeedback('Adjustment failed');
    }
    setTimeout(() => setFeedback(null), 3000);
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ settings: gameSettings }),
      });
      const data = await res.json();
      if (res.ok) {
        setSettingsSaved(true);
        setTimeout(() => setSettingsSaved(false), 2500);
        setFeedback('Game settings saved successfully!');
      } else {
        setFeedback(data.error);
      }
    } catch (e) {
      setFeedback('Failed to save settings');
    }
    setTimeout(() => setFeedback(null), 3000);
  };

  // Send Broadcast
  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMsg.trim()) return;
    setIsBroadcasting(true);
    triggerHaptic('heavy');

    try {
      const res = await fetch('/api/admin/broadcast', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ message: broadcastMsg }),
      });
      const data = await res.json();
      if (res.ok) {
        setBroadcastResult(data);
        setBroadcastMsg('');
        setFeedback(`Broadcast completed: ${data.successCount} sent, ${data.failureCount} failed.`);
      } else {
        setFeedback(data.error);
      }
    } catch (e) {
      setFeedback('Broadcast error occurred.');
    } finally {
      setIsBroadcasting(false);
      setTimeout(() => setFeedback(null), 4000);
    }
  };

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-4">
      {/* Admin Notice */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-heading font-black text-xl text-white">Admin Command Center</h2>
            <p className="text-[10px] text-amber-400 font-mono">Protected by Server Authorization</p>
          </div>
        </div>
        <button
          onClick={fetchDashboard}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200"
          title="Refresh Data"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {feedback && (
        <div className="bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs px-3 py-2 rounded-xl text-center">
          {feedback}
        </div>
      )}

      {/* Admin Subtabs */}
      <div className="flex bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-[11px] font-semibold overflow-x-auto">
        <button
          onClick={() => setActiveTab('stats')}
          className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
            activeTab === 'stats' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          Analytics
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
            activeTab === 'users' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          Users
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
            activeTab === 'settings' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          Settings
        </button>
        <button
          onClick={() => setActiveTab('broadcast')}
          className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
            activeTab === 'broadcast' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          Broadcast
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-3 py-1.5 rounded-lg transition whitespace-nowrap ${
            activeTab === 'logs' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
          }`}
        >
          Audit Logs
        </button>
      </div>

      {/* 1. Analytics & Stats */}
      {activeTab === 'stats' && (
        <div className="space-y-3">
          {stats ? (
            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Total Registered</div>
                <div className="font-heading font-black text-xl text-white mt-0.5">{stats.totalUsers}</div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Active Miners</div>
                <div className="font-heading font-black text-xl text-emerald-400 mt-0.5">{stats.activeUsers}</div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Banned Accounts</div>
                <div className="font-heading font-black text-xl text-rose-400 mt-0.5">{stats.bannedUsers}</div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Total Circulation</div>
                <div className="font-heading font-black text-xl text-amber-400 mt-0.5 flex items-center gap-1">
                  <span>🪙</span>
                  <span>{stats.totalBalance.toLocaleString()}</span>
                </div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Monetag Ad Rewards</div>
                <div className="font-heading font-black text-lg text-yellow-300 mt-0.5">
                  {stats.totalAdRewards.toLocaleString()} 🪙
                </div>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <div className="text-[11px] text-slate-400">Referral Bonuses</div>
                <div className="font-heading font-black text-lg text-cyan-300 mt-0.5">
                  {stats.totalReferralRewards.toLocaleString()} 🪙
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-xs text-slate-500">Loading stats...</div>
          )}
        </div>
      )}

      {/* 2. User Management */}
      {activeTab === 'users' && (
        <div className="space-y-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
            <input
              type="text"
              placeholder="Search by ID or username..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* User List */}
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {usersList.map((u) => (
              <div
                key={u.telegramId}
                onClick={() => setSelectedUser(u)}
                className={`p-3 rounded-xl border cursor-pointer transition ${
                  selectedUser?.telegramId === u.telegramId
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                      <span>{u.name || `User ${u.telegramId}`}</span>
                      {u.status === 'banned' && (
                        <span className="bg-rose-500/20 text-rose-300 text-[9px] px-1 rounded font-bold">
                          BANNED
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      ID: {u.telegramId} {u.username && `• @${u.username}`}
                    </div>
                  </div>
                  <div className="text-right font-mono text-xs font-bold text-amber-400">
                    🪙 {u.balance.toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Selected User Management Card */}
          {selectedUser && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 mt-3 shadow-lg">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-bold text-xs text-white">User {selectedUser.telegramId}</h4>
                  <div className="text-[10px] text-slate-400">
                    Status: <span className="font-bold capitalize text-amber-300">{selectedUser.status}</span>
                  </div>
                </div>
                <button
                  onClick={() => handleToggleBan(selectedUser)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                    selectedUser.status === 'banned'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}
                >
                  <Ban className="w-3 h-3" />
                  <span>{selectedUser.status === 'banned' ? 'Unban Account' : 'Ban Account'}</span>
                </button>
              </div>

              {/* Balance Adjuster */}
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Adjust Balance (+ / - coins):
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="e.g. 5000 or -2000"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                  <button
                    onClick={handleAdjustBalance}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition"
                  >
                    Adjust
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Reason / Note (optional)"
                  value={adjustNote}
                  onChange={(e) => setAdjustNote(e.target.value)}
                  className="w-full mt-1.5 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] text-white focus:outline-none"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. Game Settings Editor */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="space-y-3 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-amber-400" />
            <span>Economy & Game Settings</span>
          </h3>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <label className="text-[10px] text-slate-400">Welcome Bonus</label>
              <input
                type="number"
                value={gameSettings.welcomeBonus ?? 1000}
                onChange={(e) => setGameSettings({ ...gameSettings, welcomeBonus: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Referral Bonus</label>
              <input
                type="number"
                value={gameSettings.referralBonus ?? 2500}
                onChange={(e) => setGameSettings({ ...gameSettings, referralBonus: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Base Max Energy</label>
              <input
                type="number"
                value={gameSettings.baseMaxEnergy ?? 1000}
                onChange={(e) => setGameSettings({ ...gameSettings, baseMaxEnergy: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Energy Recharge / sec</label>
              <input
                type="number"
                value={gameSettings.baseRechargeRate ?? 3}
                onChange={(e) => setGameSettings({ ...gameSettings, baseRechargeRate: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Passive Mining / hr</label>
              <input
                type="number"
                value={gameSettings.baseMiningRatePerHour ?? 50}
                onChange={(e) =>
                  setGameSettings({ ...gameSettings, baseMiningRatePerHour: Number(e.target.value) })
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Monetag Reward / Ad</label>
              <input
                type="number"
                value={gameSettings.rewardPerAd ?? 1000}
                onChange={(e) => setGameSettings({ ...gameSettings, rewardPerAd: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Max Ads / Day</label>
              <input
                type="number"
                value={gameSettings.maxRewardedAdsPerDay ?? 20}
                onChange={(e) =>
                  setGameSettings({ ...gameSettings, maxRewardedAdsPerDay: Number(e.target.value) })
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">Ad Cooldown (Seconds)</label>
              <input
                type="number"
                value={gameSettings.adCooldownSeconds ?? 30}
                onChange={(e) =>
                  setGameSettings({ ...gameSettings, adCooldownSeconds: Number(e.target.value) })
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white mt-0.5 focus:border-amber-400"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs rounded-xl shadow-md transition active:scale-[0.98]"
          >
            {settingsSaved ? 'Saved Successfully! ✓' : 'Save Economy Settings'}
          </button>
        </form>
      )}

      {/* 4. Telegram Broadcast */}
      {activeTab === 'broadcast' && (
        <form onSubmit={handleBroadcast} className="space-y-3 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
          <div className="flex items-center gap-1.5">
            <Send className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-300">
              Broadcast Telegram Announcement
            </h3>
          </div>
          <p className="text-[11px] text-slate-400">
            Sends a direct message to all active registered miners via the configured Telegram Bot.
          </p>

          <textarea
            rows={4}
            placeholder="Type announcement message here (HTML formatted: <b>bold</b>, <i>italic</i>, etc.)..."
            value={broadcastMsg}
            onChange={(e) => setBroadcastMsg(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-400"
          />

          <button
            type="submit"
            disabled={isBroadcasting || !broadcastMsg.trim()}
            className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              isBroadcasting || !broadcastMsg.trim()
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md active:scale-95'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isBroadcasting ? 'Broadcasting in progress...' : 'Send Broadcast to All Users'}</span>
          </button>

          {broadcastResult && (
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] font-mono space-y-1">
              <div className="text-emerald-400">Sent Successfully: {broadcastResult.successCount}</div>
              <div className="text-rose-400">Failed / Blocked: {broadcastResult.failureCount}</div>
            </div>
          )}
        </form>
      )}

      {/* 5. Audit Logs */}
      {activeTab === 'logs' && (
        <div className="space-y-2">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400 px-1">
            System & Security Audit Logs
          </h3>

          <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
            {logs.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500">No logs recorded.</div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-[11px]">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="font-mono font-bold text-amber-300">{log.action}</span>
                    <span className="text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-slate-300 font-mono mt-0.5 break-all">
                    {JSON.stringify(log.details)}
                  </div>
                  {log.targetUserId && (
                    <div className="text-[10px] text-slate-500 mt-0.5">Target: {log.targetUserId}</div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
