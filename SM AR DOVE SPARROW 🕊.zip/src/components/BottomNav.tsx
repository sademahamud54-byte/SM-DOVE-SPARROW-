import React from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { Pickaxe, Sparkles, Zap, Users, Trophy, Award, Shield } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { isAdmin, triggerHaptic } = useTelegram();

  const navItems = [
    { id: 'home', label: 'Mine', icon: Pickaxe },
    { id: 'earn', label: 'Earn', icon: Sparkles },
    { id: 'upgrade', label: 'Boost', icon: Zap },
    { id: 'friends', label: 'Friends', icon: Users },
    { id: 'rewards', label: 'Rewards', icon: Award },
    { id: 'leaderboard', label: 'Rank', icon: Trophy },
  ];

  if (isAdmin) {
    navItems.push({ id: 'admin', label: 'Admin', icon: Shield });
  }

  const handleSelect = (id: string) => {
    triggerHaptic('light');
    setActiveTab(id);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/85 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1.5 pb-[max(0.375rem,env(safe-area-inset-bottom))]">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition duration-150 ${
                isActive
                  ? 'text-amber-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition ${
                  isActive ? 'bg-amber-400/10' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span className="text-[10px] tracking-tight mt-0.5 leading-none">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
