import React, { useState, useEffect } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { TransactionRecord } from '../types.ts';
import { Award, History, ArrowDownRight, ArrowUpRight, Sparkles, RefreshCw } from 'lucide-react';

export const RewardsTab: React.FC = () => {
  const { user, simulatedTelegramId } = useTelegram();
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSubTab, setActiveSubTab] = useState<'history' | 'achievements'>('history');

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const headers: Record<string, string> = {};
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/transactions', { headers });
      const data = await res.json();
      if (res.ok) {
        setTransactions(data.transactions || []);
      }
    } catch (err) {
      console.error('Failed to load transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [simulatedTelegramId]);

  if (!user) return null;

  const getTxTypeLabel = (type: string) => {
    switch (type) {
      case 'welcome_bonus':
        return { label: 'Welcome Bonus', color: 'text-emerald-400', isPositive: true };
      case 'tap':
        return { label: 'Tap Mining', color: 'text-amber-400', isPositive: true };
      case 'mining':
        return { label: 'Passive Mining Claim', color: 'text-purple-400', isPositive: true };
      case 'upgrade':
        return { label: 'Upgrade Purchase', color: 'text-rose-400', isPositive: false };
      case 'daily_reward':
        return { label: 'Daily Streak Bonus', color: 'text-cyan-400', isPositive: true };
      case 'task_reward':
        return { label: 'Mission Completed', color: 'text-blue-400', isPositive: true };
      case 'ad_reward':
        return { label: 'Monetag Ad Reward', color: 'text-yellow-400', isPositive: true };
      case 'referral_bonus':
        return { label: 'Referral Bonus', color: 'text-emerald-400', isPositive: true };
      case 'admin_adjustment':
        return { label: 'Admin Adjustment', color: 'text-orange-400', isPositive: true };
      default:
        return { label: type, color: 'text-slate-300', isPositive: true };
    }
  };

  const ACHIEVEMENTS = [
    {
      id: 'first_tap',
      title: 'First Strike',
      description: 'Tap the miner at least 1 time',
      progress: Math.min(1, user.statistics.totalTaps),
      goal: 1,
      reward: 100,
      completed: user.statistics.totalTaps >= 1,
    },
    {
      id: 'taps_500',
      title: 'Iron Finger',
      description: 'Reach 500 total taps',
      progress: Math.min(500, user.statistics.totalTaps),
      goal: 500,
      reward: 2000,
      completed: user.statistics.totalTaps >= 500,
    },
    {
      id: 'battery_3',
      title: 'Power Surge',
      description: 'Upgrade battery capacity to Level 3',
      progress: Math.min(3, user.upgrades.maxEnergy),
      goal: 3,
      reward: 3000,
      completed: user.upgrades.maxEnergy >= 3,
    },
    {
      id: 'invite_1',
      title: 'Mining Buddy',
      description: 'Invite your first friend',
      progress: Math.min(1, user.referrals.totalReferred),
      goal: 1,
      reward: 5000,
      completed: user.referrals.totalReferred >= 1,
    },
    {
      id: 'ad_watcher',
      title: 'Sponsor Supporter',
      description: 'Watch 5 rewarded sponsor ads',
      progress: Math.min(5, user.rewards.ads?.todayCount || 0),
      goal: 5,
      reward: 2500,
      completed: (user.rewards.ads?.todayCount || 0) >= 5,
    },
  ];

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-2xl font-black text-white flex items-center gap-2">
            <span>Rewards & History</span>
            <Award className="w-5 h-5 text-amber-400" />
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">Track your achievements and verified transactions</p>
        </div>
        <button
          onClick={fetchTransactions}
          className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-slate-200 transition"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Sub Tabs */}
      <div className="flex bg-slate-900/80 p-1 rounded-xl border border-slate-800">
        <button
          onClick={() => setActiveSubTab('history')}
          className={`flex-1 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            activeSubTab === 'history'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Transactions</span>
        </button>
        <button
          onClick={() => setActiveSubTab('achievements')}
          className={`flex-1 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            activeSubTab === 'achievements'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Achievements</span>
        </button>
      </div>

      {/* Content */}
      {activeSubTab === 'history' ? (
        <div className="space-y-2">
          {loading ? (
            <div className="text-center py-8 text-xs text-slate-500">Loading ledger...</div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-500">No transactions recorded yet.</div>
          ) : (
            transactions.map((tx) => {
              const meta = getTxTypeLabel(tx.type);
              const isPositive = tx.amount > 0;

              return (
                <div
                  key={tx.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {isPositive ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-slate-200">{meta.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {tx.note || new Date(tx.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`font-mono text-xs font-bold ${
                        isPositive ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isPositive ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()} 🪙
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      Bal: {tx.balanceAfter.toLocaleString()}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        <div className="space-y-2.5">
          {ACHIEVEMENTS.map((ach) => (
            <div
              key={ach.id}
              className={`p-3 rounded-2xl border transition ${
                ach.completed
                  ? 'bg-emerald-950/30 border-emerald-500/30'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-base">{ach.completed ? '🏆' : '🎯'}</span>
                  <div>
                    <div className="font-bold text-xs text-slate-200">{ach.title}</div>
                    <div className="text-[11px] text-slate-400">{ach.description}</div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-mono text-xs font-bold text-amber-400">+{ach.reward} 🪙</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800 mt-2">
                <div
                  className={`h-full rounded-full ${
                    ach.completed ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                  style={{ width: `${(ach.progress / ach.goal) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>Progress</span>
                <span>
                  {ach.progress} / {ach.goal} {ach.completed && '✓ Complete'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
