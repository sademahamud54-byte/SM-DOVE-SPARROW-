import React from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { X, Send, Phone, Mail, ShieldAlert, Heart, ExternalLink } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const { publicConfig, openExternalLink } = useTelegram();

  if (!isOpen) return null;

  const admin = publicConfig?.adminContact || {
    username: '',
    phone: '',
    email: '',
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl space-y-4 animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">ℹ️</span>
            <div>
              <h3 className="font-heading font-black text-base text-white">About & Support</h3>
              <p className="text-[10px] text-slate-400">Universal Telegram Mini App v1.0.0</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* App Info */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-3 text-xs space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-400">Application Name:</span>
            <span className="font-semibold text-slate-200">{publicConfig?.appName || 'Universal Mining App'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Telegram Bot:</span>
            <span className="font-mono text-amber-400">@{publicConfig?.botUsername || 'MiningBot'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Platform:</span>
            <span className="text-slate-200">Telegram & Telegram X</span>
          </div>
        </div>

        {/* Configurable Official Admin Contact (Section 6 Requirement) */}
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-400 mb-2">
            Official Administrator Support
          </h4>
          <div className="space-y-2 text-xs">
            {/* Telegram Username */}
            <div
              onClick={() => admin.username && openExternalLink(`https://t.me/${admin.username.replace('@', '')}`)}
              className="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between cursor-pointer hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-2">
                <Send className="w-4 h-4 text-sky-400" />
                <span className="text-slate-300">Admin Username:</span>
              </div>
              <span className="font-mono font-semibold text-sky-400 flex items-center gap-1">
                {admin.username ? `@${admin.username.replace('@', '')}` : 'Not configured'}
                {admin.username && <ExternalLink className="w-3 h-3" />}
              </span>
            </div>

            {/* Admin Phone */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-300">Admin Phone:</span>
              </div>
              <span className="font-mono font-semibold text-slate-200">
                {admin.phone || 'Not configured'}
              </span>
            </div>

            {/* Admin Email */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-purple-400" />
                <span className="text-slate-300">Admin Email:</span>
              </div>
              <span className="font-mono font-semibold text-slate-200 truncate max-w-[160px]">
                {admin.email || 'Not configured'}
              </span>
            </div>
          </div>
        </div>

        {/* Security & Anti-Cheat Notice */}
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3 flex items-start gap-2 text-[11px] text-amber-200/90 leading-tight">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <span>
            Protected with server-authoritative energy validation, rate limiting, and anti-cheat transaction logging.
          </span>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition"
        >
          Close
        </button>
      </div>
    </div>
  );
};
