import React, { useState } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { ShieldCheck, User, RefreshCw, ChevronDown, ChevronUp, Smartphone } from 'lucide-react';

export const SimulatorBar: React.FC = () => {
  const { isTelegram, simulatedTelegramId, setSimulatedTelegramId, isAdmin, refreshUser } = useTelegram();
  const [collapsed, setCollapsed] = useState<boolean>(true);
  const [customId, setCustomId] = useState<string>('');

  // Only render simulation bar if running outside official Telegram WebApp environment
  if (isTelegram) {
    return null;
  }

  const handleSwitchAdmin = () => {
    setSimulatedTelegramId('8801424830');
  };

  const handleSwitchUser = () => {
    setSimulatedTelegramId('1098765432');
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customId.trim()) {
      setSimulatedTelegramId(customId.trim());
      setCustomId('');
    }
  };

  return (
    <div className="bg-slate-900 border-b border-amber-500/30 text-xs px-3 py-1.5 transition-all sticky top-0 z-50 shadow-md">
      <div className="max-w-md mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-semibold text-amber-300">Telegram Dev Simulator</span>
          <span className="bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded text-[10px] font-mono">
            ID: {simulatedTelegramId}
          </span>
          {isAdmin ? (
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.5 rounded text-[10px] flex items-center gap-1 font-semibold">
              <ShieldCheck className="w-2.5 h-2.5" /> Admin
            </span>
          ) : (
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/40 px-1.5 py-0.5 rounded text-[10px] flex items-center gap-1">
              <User className="w-2.5 h-2.5" /> User
            </span>
          )}
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-slate-400 hover:text-slate-200 p-1 flex items-center gap-0.5"
        >
          {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
        </button>
      </div>

      {!collapsed && (
        <div className="max-w-md mx-auto mt-2 pt-2 border-t border-slate-800 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Quick Profile:</span>
            <button
              onClick={handleSwitchAdmin}
              className={`px-2 py-1 rounded text-[11px] font-medium transition ${
                simulatedTelegramId === '8801424830'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Admin (8801424830)
            </button>
            <button
              onClick={handleSwitchUser}
              className={`px-2 py-1 rounded text-[11px] font-medium transition ${
                simulatedTelegramId === '1098765432'
                  ? 'bg-blue-500 text-white font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Standard Miner
            </button>
          </div>

          <form onSubmit={handleCustomSubmit} className="flex gap-2">
            <input
              type="text"
              placeholder="Custom Numeric Telegram ID"
              value={customId}
              onChange={(e) => setCustomId(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded font-medium"
            >
              Set ID
            </button>
            <button
              type="button"
              onClick={() => refreshUser()}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-1.5 rounded"
              title="Refresh State"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </form>
          <div className="text-[10px] text-slate-500">
            Inside Telegram, this bar automatically hides and uses Telegram.WebApp.initData with HMAC-SHA256 signature.
          </div>
        </div>
      )}
    </div>
  );
};
