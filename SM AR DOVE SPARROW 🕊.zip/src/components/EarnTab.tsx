import React, { useState, useEffect } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { TaskDefinition } from '../types.ts';
import { Tv, Calendar, CheckCircle2, ExternalLink, Clock, Sparkles, AlertCircle, Award } from 'lucide-react';

export const EarnTab: React.FC = () => {
  const { user, updateUserState, triggerHaptic, publicConfig, simulatedTelegramId, openExternalLink } = useTelegram();
  const [tasks, setTasks] = useState<TaskDefinition[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(true);
  const [adCooldown, setAdCooldown] = useState<number>(0);
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adWatchCountdown, setAdWatchCountdown] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!user) return null;

  // Calculate live ad cooldown
  useEffect(() => {
    const updateCooldown = () => {
      const now = Date.now();
      const lastWatched = user.rewards.ads?.lastWatchedAt || 0;
      const cooldownSecs = publicConfig?.game.adCooldownSeconds || 30;
      const elapsed = Math.floor((now - lastWatched) / 1000);
      const remaining = Math.max(0, cooldownSecs - elapsed);
      setAdCooldown(remaining);
    };

    updateCooldown();
    const timer = setInterval(updateCooldown, 1000);
    return () => clearInterval(timer);
  }, [user.rewards.ads?.lastWatchedAt, publicConfig?.game.adCooldownSeconds]);

  // Load Tasks
  useEffect(() => {
    const loadTasks = async () => {
      try {
        const headers: Record<string, string> = {};
        const tg = window.Telegram?.WebApp;
        if (tg && tg.initData) {
          headers['x-telegram-init-data'] = tg.initData;
        } else {
          headers['x-telegram-sim-user-id'] = simulatedTelegramId;
        }

        const res = await fetch('/api/tasks', { headers });
        const data = await res.json();
        if (res.ok) {
          setTasks(data.tasks);
        }
      } catch (err) {
        console.error('Failed to load tasks:', err);
      } finally {
        setLoadingTasks(false);
      }
    };

    loadTasks();
  }, [simulatedTelegramId]);

  const [selectedZone, setSelectedZone] = useState<string>('zone1');

  // Watch Rewarded Ad Action
  const handleWatchAd = async (zoneKey?: string) => {
    const activeZoneKey = zoneKey || selectedZone;
    if (adCooldown > 0 || isWatchingAd) return;

    const maxAds = publicConfig?.game.maxRewardedAdsPerDay || 20;
    const currentToday = user.rewards.ads?.todayCount || 0;
    if (currentToday >= maxAds) {
      setToastMessage(`Daily limit reached (${maxAds} ads). Come back tomorrow!`);
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }

    triggerHaptic('medium');
    setIsWatchingAd(true);
    setAdWatchCountdown(5);

    // 5-second simulated rewarded video playback
    const countdownInterval = setInterval(() => {
      setAdWatchCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownInterval);
          finalizeAdReward(activeZoneKey);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const finalizeAdReward = async (activeZoneKey: string) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const zoneId =
        (publicConfig?.monetag as any)?.[activeZoneKey] ||
        publicConfig?.monetag?.zone1 ||
        '11924593';

      const res = await fetch('/api/ad/reward', {
        method: 'POST',
        headers,
        body: JSON.stringify({ zoneId }),
      });

      const data = await res.json();
      if (res.ok) {
        triggerHaptic('heavy');
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          rewards: {
            ...prev.rewards,
            ads: {
              ...prev.rewards.ads,
              todayCount: (prev.rewards.ads?.todayCount || 0) + 1,
              lastWatchedAt: Date.now(),
            },
          },
        }));
        setToastMessage(`🎉 Ad completed (Zone ${zoneId})! Received +${data.reward.toLocaleString()} coins!`);
      } else {
        setToastMessage(data.error || 'Failed to claim ad reward');
      }
    } catch (err: any) {
      setToastMessage('Network error occurred.');
    } finally {
      setIsWatchingAd(false);
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  // Claim Daily Streak Reward
  const handleClaimDailyReward = async () => {
    triggerHaptic('medium');
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/daily-reward/claim', {
        method: 'POST',
        headers,
      });

      const data = await res.json();
      if (res.ok) {
        triggerHaptic('heavy');
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          rewards: {
            ...prev.rewards,
            dailyStreak: data.dailyStreak,
          },
        }));
        setToastMessage(`🎁 Day ${data.day} Bonus Claimed! +${data.reward.toLocaleString()} coins!`);
      } else {
        setToastMessage(data.error || 'Failed to claim daily reward');
      }
    } catch (err: any) {
      setToastMessage('Network error');
    } finally {
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  // Claim Task
  const handleClaimTask = async (task: TaskDefinition) => {
    triggerHaptic('light');

    if (task.link && !task.completed) {
      openExternalLink(task.link);
    }

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/task/claim', {
        method: 'POST',
        headers,
        body: JSON.stringify({ taskId: task.id }),
      });

      const data = await res.json();
      if (res.ok) {
        triggerHaptic('heavy');
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          tasks: {
            ...prev.tasks,
            [task.id]: { completed: true, claimedAt: Date.now() },
          },
        }));
        setTasks((prev) =>
          prev.map((t) => (t.id === task.id ? { ...t, completed: true, claimedAt: Date.now() } : t))
        );
        setToastMessage(`✅ Task completed! +${task.reward.toLocaleString()} coins!`);
      } else {
        setToastMessage(data.error || 'Task requirements not satisfied yet.');
      }
    } catch (err: any) {
      setToastMessage('Error completing task.');
    } finally {
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const isDailyClaimedToday = user.rewards.dailyStreak?.lastClaimDate === todayStr;
  const currentStreakDay = user.rewards.dailyStreak?.currentDay || 1;
  const dailyRewardsSchedule = publicConfig?.game.dailyRewards || [500, 1000, 2000, 5000, 10000, 20000, 50000];

  const adsWatchedToday = user.rewards.ads?.todayCount || 0;
  const maxAdsToday = publicConfig?.game.maxRewardedAdsPerDay || 20;

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-5">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-amber-500 text-amber-200 text-xs px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 max-w-xs text-center animate-fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Ad Watching Modal Overlay */}
      {isWatchingAd && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-4 animate-bounce">
            <Tv className="w-8 h-8" />
          </div>
          <h3 className="font-heading text-xl font-bold text-white">Monetag Sponsored Ad</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            Viewing rewarded sponsor content. Please wait for the countdown to complete to claim your reward.
          </p>
          <div className="mt-6 font-mono text-4xl font-extrabold text-amber-400">
            00:0{adWatchCountdown}
          </div>
          <div className="mt-4 text-[11px] text-slate-500">Reward will be accredited automatically</div>
        </div>
      )}

      {/* Header Banner */}
      <div>
        <h2 className="font-heading text-2xl font-black text-white flex items-center gap-2">
          <span>Earn Free Coins</span>
          <Sparkles className="w-5 h-5 text-amber-400" />
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Watch sponsored ads, log in daily, and complete community quests
        </p>
      </div>

      {/* Monetag Rewarded Ads Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/30 border border-amber-500/30 rounded-2xl p-4 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Tv className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                <span>Watch Rewarded Ad</span>
                <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 py-0.2 rounded font-semibold">
                  +{publicConfig?.game.rewardPerAd.toLocaleString() || '1,000'}
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Daily Limit: <span className="text-slate-200 font-semibold">{adsWatchedToday} / {maxAdsToday}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => handleWatchAd(selectedZone)}
            disabled={adCooldown > 0 || isWatchingAd || adsWatchedToday >= maxAdsToday}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              adCooldown > 0 || adsWatchedToday >= maxAdsToday
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95'
            }`}
          >
            {adCooldown > 0 ? (
              <>
                <Clock className="w-3.5 h-3.5" />
                <span>{adCooldown}s</span>
              </>
            ) : adsWatchedToday >= maxAdsToday ? (
              <span>Maxed</span>
            ) : (
              <>
                <Tv className="w-3.5 h-3.5" />
                <span>Watch</span>
              </>
            )}
          </button>
        </div>

        {/* Monetag 4-Zone Switcher */}
        <div className="border-t border-slate-800/80 pt-2.5">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
            <span>Monetag Ad Channels:</span>
            <span className="font-mono text-[10px] text-amber-400">
              Zone ID: {(publicConfig?.monetag as any)?.[selectedZone] || '11924593'}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[
              { key: 'zone1', label: 'Zone 1', id: publicConfig?.monetag.zone1 || '11924593', desc: 'Interstitial' },
              { key: 'zone2', label: 'Zone 2', id: publicConfig?.monetag.zone2 || '11924529', desc: 'Rewarded' },
              { key: 'zone3', label: 'Zone 3', id: publicConfig?.monetag.zone3 || '11924571', desc: 'In-App' },
              { key: 'zone4', label: 'Zone 4', id: publicConfig?.monetag.zone4 || '11949016', desc: 'Pop/Push' },
            ].map((z) => (
              <button
                key={z.key}
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setSelectedZone(z.key);
                }}
                className={`py-1.5 px-1 rounded-xl text-center border transition ${
                  selectedZone === z.key
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="text-[10px] font-semibold">{z.label}</div>
                <div className="text-[8px] font-mono text-slate-400 truncate">{z.id}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Daily Login Rewards Roadmap */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-sm text-slate-100">7-Day Login Streak</h3>
          </div>
          <span className="text-xs text-amber-400 font-semibold">Day {currentStreakDay} / 7</span>
        </div>

        {/* 7 Day Grid */}
        <div className="grid grid-cols-7 gap-1.5 mb-3">
          {dailyRewardsSchedule.map((reward, index) => {
            const dayNum = index + 1;
            const isCompleted = dayNum < currentStreakDay || (dayNum === currentStreakDay && isDailyClaimedToday);
            const isToday = dayNum === currentStreakDay && !isDailyClaimedToday;

            return (
              <div
                key={dayNum}
                className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition ${
                  isCompleted
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                    : isToday
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 ring-2 ring-amber-400/40'
                    : 'bg-slate-950/60 border-slate-800 text-slate-500'
                }`}
              >
                <span className="text-[10px] font-semibold">D{dayNum}</span>
                <span className="text-xs my-0.5">{isCompleted ? '✓' : '🪙'}</span>
                <span className="text-[9px] font-mono leading-none">
                  {reward >= 1000 ? `${reward / 1000}k` : reward}
                </span>
              </div>
            );
          })}
        </div>

        <button
          onClick={handleClaimDailyReward}
          disabled={isDailyClaimedToday}
          className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            isDailyClaimedToday
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
              : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20 active:scale-[0.98]'
          }`}
        >
          {isDailyClaimedToday ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Claimed Today — Come Back Tomorrow</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Claim Day {currentStreakDay} Bonus (+{dailyRewardsSchedule[currentStreakDay - 1]?.toLocaleString()} coins)</span>
            </>
          )}
        </button>
      </div>

      {/* Community Tasks List */}
      <div>
        <h3 className="font-bold text-sm text-slate-200 mb-2.5 flex items-center gap-1.5">
          <Award className="w-4 h-4 text-amber-400" />
          <span>Quests & Missions</span>
        </h3>

        {loadingTasks ? (
          <div className="text-center py-6 text-xs text-slate-500">Loading missions...</div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-500">No active quests right now.</div>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => {
              const isClaimed = !!user.tasks[task.id]?.completed;

              return (
                <div
                  key={task.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between shadow-md"
                >
                  <div className="flex-1 pr-2">
                    <div className="font-semibold text-xs text-slate-100 flex items-center gap-1">
                      <span>{task.title}</span>
                      {task.link && <ExternalLink className="w-3 h-3 text-slate-500" />}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{task.description}</div>
                    <div className="mt-1 flex items-center gap-1 font-mono text-[11px] font-bold text-amber-400">
                      🪙 +{task.reward.toLocaleString()}
                    </div>
                  </div>

                  <button
                    onClick={() => handleClaimTask(task)}
                    disabled={isClaimed}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0 ${
                      isClaimed
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm active:scale-95'
                    }`}
                  >
                    {isClaimed ? 'Claimed' : 'Complete'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
