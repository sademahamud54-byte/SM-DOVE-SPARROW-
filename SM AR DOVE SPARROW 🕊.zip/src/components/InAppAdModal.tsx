import React, { useState, useEffect, useRef } from 'react';
import { AdSlot } from '../services/adRotation.ts';
import { Tv, X, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';

interface InAppAdModalProps {
  isOpen: boolean;
  adSlot: AdSlot;
  onAdCompleted: (zoneId: string) => void;
  onAdClosed: () => void;
}

export const InAppAdModal: React.FC<InAppAdModalProps> = ({
  isOpen,
  adSlot,
  onAdCompleted,
  onAdClosed,
}) => {
  const [countdown, setCountdown] = useState<number>(15);
  const [canSkip, setCanSkip] = useState<boolean>(false);
  const [rewardClaimed, setRewardClaimed] = useState<boolean>(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(15);
      setCanSkip(false);
      setRewardClaimed(false);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    setCountdown(15);
    setCanSkip(false);
    setRewardClaimed(false);

    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 6) {
          // At 10 seconds elapsed (15 - 5 = 10, so prev <= 5 or 6)
          setCanSkip(true);
        }
        if (prev <= 1) {
          // Reached 15 seconds: auto close and finalize
          clearInterval(timerRef.current);
          handleFinalize();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen]);

  const handleFinalize = () => {
    if (rewardClaimed) return;
    setRewardClaimed(true);
    if (timerRef.current) clearInterval(timerRef.current);
    onAdCompleted(adSlot.zoneId);
  };

  const handleManualClose = () => {
    if (!canSkip && countdown > 5) return;
    handleFinalize();
  };

  if (!isOpen) return null;

  const secondsElapsed = 15 - countdown;
  const progressPercent = Math.min(100, Math.round((secondsElapsed / 15) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col justify-between p-4 select-none animate-fade-in">
      {/* Top Bar with Slot Info & Close Button */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
            <Tv className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Monetag Sponsored Ad</span>
              <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 py-0.2 rounded font-mono">
                Slot {adSlot.slotIndex + 1}/12
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              Zone {adSlot.zoneIndex + 1} ({adSlot.zoneId}) • Ad {adSlot.adNumberInZone}/3
            </div>
          </div>
        </div>

        {/* Close Button: Unlocks after 10 seconds */}
        <button
          onClick={handleManualClose}
          disabled={!canSkip}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
            canSkip
              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/40'
          }`}
          title={canSkip ? 'Close ad & claim reward' : `Wait ${countdown - 5}s to close`}
        >
          {canSkip ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-slate-950" />
              <span>Close (×)</span>
            </>
          ) : (
            <>
              <X className="w-3.5 h-3.5 text-slate-500" />
              <span>Skip in {Math.max(1, countdown - 5)}s</span>
            </>
          )}
        </button>
      </div>

      {/* Main Sponsored Content Frame (Completely within bot viewport) */}
      <div className="my-auto flex flex-col items-center justify-center text-center px-4 py-8">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-5 shadow-2xl animate-pulse">
          <Sparkles className="w-10 h-10" />
        </div>

        <h3 className="font-heading font-black text-2xl text-white tracking-wide">
          SM DOVE SPARROW SPONSOR
        </h3>

        <p className="text-xs text-slate-400 mt-2 max-w-xs leading-relaxed">
          Viewing authorized in-bot sponsored broadcast for <span className="text-amber-300 font-semibold">{adSlot.label}</span>.
          No external site navigation required.
        </p>

        {/* Live Countdown Clock */}
        <div className="mt-8 bg-slate-900/90 border border-slate-800 rounded-2xl px-6 py-4 shadow-xl flex flex-col items-center">
          <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
            {countdown > 5 ? 'Mandatory Viewing' : 'Reward Available'}
          </div>
          <div className="text-4xl font-mono font-black text-amber-400 mt-1">
            00:{countdown < 10 ? `0${countdown}` : countdown}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {countdown > 5
              ? `You can close in ${countdown - 5} seconds`
              : 'Auto-completes at 15s or tap Close (×) above'}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full max-w-xs bg-slate-900 rounded-full h-2 mt-6 overflow-hidden border border-slate-800">
          <div
            className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full transition-all duration-1000 ease-linear"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Security & Sandbox Cleanliness Badge */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>In-Bot Sandboxed Player • Safe from external redirects</span>
        </div>
        <span className="font-mono text-amber-400 font-bold">+1 SM Coin</span>
      </div>
    </div>
  );
};
