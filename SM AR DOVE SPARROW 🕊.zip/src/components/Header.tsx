import React from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { Shield, Info, Copy, Check } from 'lucide-react';

interface HeaderProps {
  onOpenAbout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAbout, activeTab, setActiveTab }) => {
  const { user, isAdmin, triggerHaptic } = useTelegram();
  const [copied, setCopied] = React.useState(false);

  if (!user) return null;

  const handleCopyId = () => {
    triggerHaptic('light');
    navigator.clipboard.writeText(user.profile.telegramId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getInitials = () => {
    const fn = user.profile.firstName || 'T';
    const ln = user.profile.lastName || '';
    return `${fn[0] || ''}${ln[0] || ''}`.toUpperCase() || 'TG';
  };

  return (
    <header className="px-4 py-3 bg-slate-900/60 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* User Profile Badge */}
        <div className="flex items-center space-x-2.5">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center text-amber-300 font-bold text-sm">
              {getInitials()}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-sm text-slate-100 leading-tight">
                {user.profile.firstName || 'Miner'}
              </span>
              {user.profile.username && (
                <span className="text-xs text-slate-400">@{user.profile.username}</span>
              )}
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="text-[11px] font-mono text-slate-400">ID: {user.profile.telegramId}</span>
              <button
                onClick={handleCopyId}
                className="text-slate-400 hover:text-amber-400 p-0.5 transition"
                title="Copy ID"
              >
                {copied ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center space-x-2">
          {isAdmin && (
            <button
              onClick={() => {
                triggerHaptic('medium');
                setActiveTab(activeTab === 'admin' ? 'home' : 'admin');
              }}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition border ${
                activeTab === 'admin'
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          )}

          <button
            onClick={() => {
              triggerHaptic('light');
              onOpenAbout();
            }}
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition"
            title="About & Support"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
