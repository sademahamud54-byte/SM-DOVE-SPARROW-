import React, { useState, useEffect } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { Users, Copy, Check, Share2, Sparkles, Gift } from 'lucide-react';

export const FriendsTab: React.FC = () => {
  const { user, publicConfig, triggerHaptic, openExternalLink, simulatedTelegramId } = useTelegram();
  const [copied, setCopied] = useState(false);
  const [referralData, setReferralData] = useState<{
    referralLink: string;
    referralBonus: number;
    totalReferred: number;
    totalEarned: number;
    referredUsers: Array<any>;
  } | null>(null);

  useEffect(() => {
    const fetchReferrals = async () => {
      try {
        const headers: Record<string, string> = {};
        const tg = window.Telegram?.WebApp;
        if (tg && tg.initData) {
          headers['x-telegram-init-data'] = tg.initData;
        } else {
          headers['x-telegram-sim-user-id'] = simulatedTelegramId;
        }

        const res = await fetch('/api/referrals', { headers });
        const data = await res.json();
        if (res.ok) {
          setReferralData(data);
        }
      } catch (err) {
        console.error('Failed to load referrals:', err);
      }
    };

    fetchReferrals();
  }, [simulatedTelegramId]);

  if (!user) return null;

  const botUsername = publicConfig?.botUsername || 'MiningBot';
  const referralLink =
    referralData?.referralLink || `https://t.me/${botUsername}?start=ref_${user.profile.telegramId}`;
  const bonusAmount = publicConfig?.game.referralBonus || 2500;

  const handleCopy = () => {
    triggerHaptic('light');
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareTelegram = () => {
    triggerHaptic('medium');
    const shareText = encodeURIComponent(
      `🚀 Join me on ${publicConfig?.appName || 'Telegram Mining App'}!\n` +
      `⚡ Tap, mine crypto tokens, and earn passive rewards.\n` +
      `🎁 Use my exclusive invite link to get +${bonusAmount.toLocaleString()} welcome bonus!`
    );
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${shareText}`;
    openExternalLink(shareUrl);
  };

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-4">
      {/* Header */}
      <div>
        <h2 className="font-heading text-2xl font-black text-white flex items-center gap-2">
          <span>Invite Friends</span>
          <Users className="w-6 h-6 text-amber-400" />
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Grow your mining network and earn massive referral rewards
        </p>
      </div>

      {/* Bonus Hero Banner */}
      <div className="bg-gradient-to-br from-amber-500/20 via-slate-900 to-slate-900 border border-amber-500/40 rounded-2xl p-4 shadow-xl relative overflow-hidden">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1">
              <Gift className="w-3.5 h-3.5" /> Referral Program
            </span>
            <div className="font-heading text-xl font-black text-white">
              +{bonusAmount.toLocaleString()}{' '}
              <span className="text-sm font-normal text-amber-300">coins per friend</span>
            </div>
            <p className="text-xs text-slate-300">
              Your invited buddy also receives a bonus to kickstart their mining journey!
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-3xl shadow-inner shrink-0">
            🤝
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 flex gap-2">
          <button
            onClick={handleShareTelegram}
            className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5 transition active:scale-[0.98]"
          >
            <Share2 className="w-4 h-4" />
            <span>Invite a Friend 🚀</span>
          </button>
          <button
            onClick={handleCopy}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
            title="Copy Invite Link"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Stats Counter */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 shadow-md">
          <div className="text-xs text-slate-400 font-medium">Friends Invited</div>
          <div className="font-heading text-2xl font-black text-white mt-1">
            {user.referrals.totalReferred}
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 shadow-md">
          <div className="text-xs text-slate-400 font-medium">Referral Earnings</div>
          <div className="font-heading text-2xl font-black text-amber-400 mt-1 flex items-center gap-1">
            <span className="text-base">🪙</span>
            <span>{user.referrals.totalEarned.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Referral Link Preview Card */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between">
        <div className="overflow-hidden mr-2">
          <div className="text-[10px] text-slate-400 uppercase font-medium">Your Telegram Invite Link</div>
          <div className="text-xs font-mono text-slate-300 truncate mt-0.5">{referralLink}</div>
        </div>
        <button
          onClick={handleCopy}
          className="text-xs text-amber-400 hover:text-amber-300 font-semibold px-2 py-1 rounded bg-amber-500/10 shrink-0"
        >
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>

      {/* Friends List */}
      <div>
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400 mb-2 px-1">
          Invited Friends ({user.referrals.referredUsers?.length || 0})
        </h3>

        {!user.referrals.referredUsers || user.referrals.referredUsers.length === 0 ? (
          <div className="bg-slate-900/40 border border-dashed border-slate-800 rounded-2xl p-6 text-center">
            <span className="text-3xl">👥</span>
            <div className="font-bold text-sm text-slate-300 mt-2">No friends invited yet</div>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Share your personal invite link above and receive +{bonusAmount.toLocaleString()} coins for each buddy who joins!
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {user.referrals.referredUsers.map((friend, idx) => (
              <div
                key={idx}
                className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300">
                    {friend.username ? friend.username[0]?.toUpperCase() : 'F'}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-100">
                      {friend.username ? `@${friend.username}` : `User ${friend.telegramId}`}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {new Date(friend.joinedAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="font-mono text-xs font-bold text-emerald-400">
                  +{friend.bonusEarned?.toLocaleString() || bonusAmount.toLocaleString()} 🪙
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
