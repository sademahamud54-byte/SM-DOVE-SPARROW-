import React, { useState } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { UserUpgrades } from '../types.ts';
import { Zap, BatteryCharging, Pickaxe, Gauge, TrendingUp, AlertCircle, Sparkles } from 'lucide-react';

interface UpgradeItem {
  id: keyof UserUpgrades;
  name: string;
  description: string;
  icon: React.ReactNode;
  baseCost: number;
  costMultiplier: number;
  maxLevel: number;
  effectLabel: (level: number) => string;
  nextEffectLabel: (level: number) => string;
}

const UPGRADES: UpgradeItem[] = [
  {
    id: 'tapPower',
    name: 'Tap Power',
    description: 'Earn more tokens with every tap',
    icon: <Zap className="w-5 h-5 text-amber-400" />,
    baseCost: 100,
    costMultiplier: 1.8,
    maxLevel: 25,
    effectLabel: (lvl) => `+${lvl} coins / tap`,
    nextEffectLabel: (lvl) => `+${lvl + 1} coins / tap`,
  },
  {
    id: 'maxEnergy',
    name: 'Battery Capacity',
    description: 'Expand your energy battery reserve',
    icon: <BatteryCharging className="w-5 h-5 text-emerald-400" />,
    baseCost: 150,
    costMultiplier: 1.6,
    maxLevel: 25,
    effectLabel: (lvl) => `${1000 + (lvl - 1) * 500} Max Energy`,
    nextEffectLabel: (lvl) => `${1000 + lvl * 500} Max Energy`,
  },
  {
    id: 'rechargeRate',
    name: 'Fast Recharge',
    description: 'Recharge your energy battery faster',
    icon: <Gauge className="w-5 h-5 text-cyan-400" />,
    baseCost: 200,
    costMultiplier: 2.0,
    maxLevel: 20,
    effectLabel: (lvl) => `+${3 + (lvl - 1) * 2} energy / sec`,
    nextEffectLabel: (lvl) => `+${3 + lvl * 2} energy / sec`,
  },
  {
    id: 'miningRate',
    name: 'Passive Rig',
    description: 'Mine coins continuously while you sleep',
    icon: <Pickaxe className="w-5 h-5 text-purple-400" />,
    baseCost: 250,
    costMultiplier: 2.2,
    maxLevel: 30,
    effectLabel: (lvl) => `+${50 + (lvl - 1) * 100} coins / hr`,
    nextEffectLabel: (lvl) => `+${50 + lvl * 100} coins / hr`,
  },
  {
    id: 'multiplier',
    name: 'Yield Booster',
    description: 'Multiplier for all tap earnings',
    icon: <TrendingUp className="w-5 h-5 text-rose-400" />,
    baseCost: 500,
    costMultiplier: 2.5,
    maxLevel: 15,
    effectLabel: (lvl) => `${(1 + (lvl - 1) * 0.2).toFixed(1)}x Multiplier`,
    nextEffectLabel: (lvl) => `${(1 + lvl * 0.2).toFixed(1)}x Multiplier`,
  },
];

export const UpgradeTab: React.FC = () => {
  const { user, updateUserState, triggerHaptic, simulatedTelegramId } = useTelegram();
  const [upgradingId, setUpgradingId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!user) return null;

  const calculateCost = (upgrade: UpgradeItem, currentLevel: number): number => {
    return Math.round(upgrade.baseCost * Math.pow(upgrade.costMultiplier, currentLevel - 1));
  };

  const handleUpgrade = async (upgrade: UpgradeItem) => {
    const currentLevel = user.upgrades[upgrade.id] || 1;
    if (currentLevel >= upgrade.maxLevel) return;

    const cost = calculateCost(upgrade, currentLevel);
    if (user.balance < cost) {
      triggerHaptic('heavy');
      setToastMessage(`Not enough coins! You need ${cost.toLocaleString()} coins.`);
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }

    setUpgradingId(upgrade.id);
    triggerHaptic('medium');

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/upgrade', {
        method: 'POST',
        headers,
        body: JSON.stringify({ type: upgrade.id }),
      });

      const data = await res.json();
      if (res.ok) {
        triggerHaptic('heavy');
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          upgrades: data.upgrades,
          energy: data.energy,
          mining: data.mining,
        }));
        setToastMessage(`⚡ Upgraded ${upgrade.name} to Level ${currentLevel + 1}!`);
      } else {
        setToastMessage(data.error || 'Upgrade failed');
      }
    } catch (err: any) {
      setToastMessage('Network error occurred.');
    } finally {
      setUpgradingId(null);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-4">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-amber-500 text-amber-200 text-xs px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 max-w-xs text-center animate-fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div>
        <h2 className="font-heading text-2xl font-black text-white flex items-center gap-2">
          <span>Mining Upgrades</span>
          <Sparkles className="w-5 h-5 text-amber-400" />
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Boost your tap power, battery capacity, recharge speed, and passive income
        </p>
      </div>

      {/* User Balance Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between shadow-md">
        <span className="text-xs text-slate-400">Available Balance:</span>
        <div className="flex items-center gap-1.5 font-heading font-extrabold text-amber-400 text-lg">
          <span>🪙</span>
          <span>{user.balance.toLocaleString()}</span>
        </div>
      </div>

      {/* Upgrades List */}
      <div className="space-y-3">
        {UPGRADES.map((upgrade) => {
          const currentLevel = user.upgrades[upgrade.id] || 1;
          const isMax = currentLevel >= upgrade.maxLevel;
          const cost = calculateCost(upgrade, currentLevel);
          const canAfford = user.balance >= cost;
          const isProcessing = upgradingId === upgrade.id;

          return (
            <div
              key={upgrade.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 shadow-md flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-inner">
                  {upgrade.icon}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-slate-100">{upgrade.name}</span>
                    <span className="bg-slate-800 text-slate-400 text-[10px] font-mono px-1.5 py-0.5 rounded">
                      Lv. {currentLevel}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{upgrade.description}</div>
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold mt-1">
                    <span className="text-emerald-400">{upgrade.effectLabel(currentLevel)}</span>
                    {!isMax && (
                      <>
                        <span className="text-slate-600">→</span>
                        <span className="text-amber-400 font-bold">{upgrade.nextEffectLabel(currentLevel)}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleUpgrade(upgrade)}
                disabled={isMax || !canAfford || isProcessing}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center shrink-0 min-w-[76px] ${
                  isMax
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                    : canAfford
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95'
                    : 'bg-slate-800 text-slate-400 border border-slate-700/50 cursor-not-allowed opacity-70'
                }`}
              >
                {isMax ? (
                  <span>MAX</span>
                ) : (
                  <>
                    <span className="text-[10px] uppercase text-slate-900 font-extrabold">UPGRADE</span>
                    <span className="font-mono text-[11px] font-black text-slate-950">
                      {isProcessing ? '...' : `🪙 ${cost >= 1000 ? `${(cost / 1000).toFixed(1)}k` : cost}`}
                    </span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
