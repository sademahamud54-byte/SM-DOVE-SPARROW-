import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { Zap, Pickaxe, Award, Sparkles, AlertCircle, Tv } from 'lucide-react';
import {
  getAdSlotForIndex,
  loadStoredRotationIndex,
  saveStoredRotationIndex,
  loadStoredLogicalTaps,
  saveStoredLogicalTaps,
  TAPS_PER_AD,
  TOTAL_AD_SLOTS,
  AdSlot,
} from '../services/adRotation.ts';
import { InAppAdModal } from './InAppAdModal.tsx';
import { tapRobotNormal, tapRobotWinking } from '../assets/index.ts';

interface FloatingNumber {
  id: number;
  x: number;
  y: number;
  value: number;
}

// Dynamic reward sequences requested by the user:
// Single tap: 5, 5, 10, 10, 10, 15, 15, 10, 5, 5, 15, 10
const SINGLE_TAP_SEQUENCE = [5, 5, 10, 10, 10, 15, 15, 10, 5, 5, 15, 10];
// Multi-finger tap: starts with 5, 5, then 10, 15, 10, 8, 20, 12, 10, 15, 8, 20
const MULTI_TAP_SEQUENCE = [5, 5, 10, 15, 10, 8, 20, 12, 10, 15, 8, 20];

export const HomeTab: React.FC = () => {
  const { user, updateUserState, triggerHaptic, simulatedTelegramId, publicConfig } = useTelegram();
  const [floatingNumbers, setFloatingNumbers] = useState<FloatingNumber[]>([]);
  const [isClaimingMining, setIsClaimingMining] = useState(false);
  const [claimMessage, setClaimMessage] = useState<string | null>(null);
  const [isPressing, setIsPressing] = useState(false);
  const [isBalancePopping, setIsBalancePopping] = useState(false);
  const [isWinking, setIsWinking] = useState(false);

  // Logical Tap & Ad Rotation State
  const [logicalTapCount, setLogicalTapCount] = useState<number>(() => loadStoredLogicalTaps());
  const [adRotationIndex, setAdRotationIndex] = useState<number>(() => loadStoredRotationIndex());
  const [isAdShowing, setIsAdShowing] = useState<boolean>(false);
  const [activeAdSlot, setActiveAdSlot] = useState<AdSlot | null>(null);

  // Dynamic Tap Sequence Index
  const tapSequenceIndexRef = useRef<number>(0);

  // Touch Deduplication Refs
  const lastTouchTimeRef = useRef<number>(0);
  const isTouchActiveRef = useRef<boolean>(false);

  // Tap batching refs for backend sync
  const pendingTapsRef = useRef<number>(0);
  const pendingCoinsRef = useRef<number>(0);
  const syncTimeoutRef = useRef<any>(null);

  if (!user) return null;

  // Local live energy ticker (synced with user's rechargeRate)
  useEffect(() => {
    const interval = setInterval(() => {
      updateUserState((prev) => {
        if (!prev) return prev;
        if (prev.energy.current < prev.energy.max) {
          const newCurrent = Math.min(prev.energy.max, prev.energy.current + prev.energy.rechargeRate);
          return {
            ...prev,
            energy: {
              ...prev.energy,
              current: newCurrent,
              lastUpdated: Date.now(),
            },
          };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [updateUserState]);

  // Sync queued taps to backend
  const syncPendingTaps = useCallback(async () => {
    const tapsToSync = pendingTapsRef.current;
    const coinsToSync = pendingCoinsRef.current;
    if (tapsToSync <= 0) return;

    pendingTapsRef.current = 0;
    pendingCoinsRef.current = 0;

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/tap', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          taps: tapsToSync,
          coins: coinsToSync,
          timestamp: Date.now(),
        }),
      });

      const data = await res.json();
      if (res.ok) {
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          energy: data.energy,
          level: data.level,
        }));
      } else {
        console.warn('Tap sync rejected by server:', data.error);
        setClaimMessage(data.error);
        setTimeout(() => setClaimMessage(null), 3000);
      }
    } catch (err) {
      console.error('Failed to sync taps:', err);
    }
  }, [simulatedTelegramId, updateUserState]);

  // Trigger Ad when logical taps reach 20
  const triggerAdRotation = useCallback(() => {
    if (isAdShowing) return;

    // Get current ad slot from circular 12-slot rotation
    const currentSlot = getAdSlotForIndex(adRotationIndex, publicConfig);
    setActiveAdSlot(currentSlot);
    setIsAdShowing(true);

    // Advance rotation index for the next ad: (index + 1) % 12
    const nextIndex = (adRotationIndex + 1) % TOTAL_AD_SLOTS;
    setAdRotationIndex(nextIndex);
    saveStoredRotationIndex(nextIndex);

    // Sync any pending taps immediately before ad shows
    syncPendingTaps();
  }, [adRotationIndex, isAdShowing, publicConfig, syncPendingTaps]);

  // Core processing for 1 logical tap gesture
  const processLogicalTap = (clientX: number, clientY: number, isMultiTouch: boolean) => {
    // If ad is currently showing, prevent tapping
    if (isAdShowing) return;

    // Check energy
    if (user.energy.current <= 0) {
      triggerHaptic('heavy');
      setClaimMessage('Battery empty! Wait for energy to recharge.');
      setTimeout(() => setClaimMessage(null), 2500);
      return;
    }

    // Dynamic Reward Calculation:
    // Single tap uses SINGLE_TAP_SEQUENCE (5, 5, 10, 10, 10, 15...)
    // Multi tap uses MULTI_TAP_SEQUENCE (5, 5, 10, 15, 10, 8, 20, 12...)
    const seq = isMultiTouch ? MULTI_TAP_SEQUENCE : SINGLE_TAP_SEQUENCE;
    const baseReward = seq[tapSequenceIndexRef.current % seq.length];
    tapSequenceIndexRef.current += 1;

    // Apply Upgrade Bonuses
    const tapPowerLevel = user.upgrades?.tapPower || 1;
    const multiplierLevel = user.upgrades?.multiplier || 1;
    const upgradeBonus = Math.max(0, (tapPowerLevel - 1) * 2);
    const coinsAwarded = Math.round((baseReward + upgradeBonus) * (1 + (multiplierLevel - 1) * 0.2));

    triggerHaptic(isMultiTouch ? 'medium' : 'light');
    setIsPressing(true);
    setIsWinking(true);
    setTimeout(() => setIsPressing(false), 120);
    setTimeout(() => setIsWinking(false), 300);

    // Pop animation on the top balance header
    setIsBalancePopping(true);
    setTimeout(() => setIsBalancePopping(false), 240);

    // Add floating number animation (High flight path towards top balance)
    const newId = Date.now() + Math.random();
    setFloatingNumbers((prev) => [
      ...prev,
      { id: newId, x: clientX, y: clientY, value: coinsAwarded },
    ]);
    setTimeout(() => {
      setFloatingNumbers((prev) => prev.filter((item) => item.id !== newId));
    }, 1350);

    // Optimistic local update
    updateUserState((prev) => ({
      ...prev,
      balance: prev.balance + coinsAwarded,
      energy: {
        ...prev.energy,
        current: Math.max(0, prev.energy.current - 1),
      },
      statistics: {
        ...prev.statistics,
        totalTaps: prev.statistics.totalTaps + 1,
      },
    }));

    // Queue tap and coin amount for backend sync
    pendingTapsRef.current += 1;
    pendingCoinsRef.current += coinsAwarded;
    if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
    syncTimeoutRef.current = setTimeout(syncPendingTaps, 500);

    // 1. Unified Logical Tap Counting:
    // Every separate gesture = exactly 1 logical tap
    const nextCount = logicalTapCount + 1;

    // 2. Check 20 Taps threshold
    if (nextCount >= TAPS_PER_AD) {
      const remainder = nextCount - TAPS_PER_AD;
      setLogicalTapCount(remainder);
      saveStoredLogicalTaps(remainder);
      triggerAdRotation();
    } else {
      setLogicalTapCount(nextCount);
      saveStoredLogicalTaps(nextCount);
    }
  };

  // Touch Start Handler (Multi-finger simultaneous gesture = 1 logical tap)
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    e.preventDefault();
    const now = Date.now();

    // Debounce simultaneous multi-touch within 90ms window
    if (now - lastTouchTimeRef.current < 90) {
      return;
    }

    lastTouchTimeRef.current = now;
    isTouchActiveRef.current = true;

    const isMultiTouch = e.touches.length >= 2;

    // Get primary touch coordinates for floating number
    const touch = e.touches[0];
    const clientX = touch ? touch.clientX : window.innerWidth / 2;
    const clientY = touch ? touch.clientY : window.innerHeight / 2;

    processLogicalTap(clientX, clientY, isMultiTouch);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 0) {
      isTouchActiveRef.current = false;
    }
  };

  // Mouse Down Handler for desktop testing (safeguarded against duplicate touch events)
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const now = Date.now();
    // If a touch occurred within 400ms, ignore this synthesized mouse click
    if (now - lastTouchTimeRef.current < 400) {
      return;
    }

    processLogicalTap(e.clientX, e.clientY, false);
  };

  // Handle ad completion from InAppAdModal
  const handleAdCompleted = async (zoneId: string) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/ad/reward', {
        method: 'POST',
        headers,
        body: JSON.stringify({ zoneId }),
      });

      const data = await res.json();
      if (res.ok) {
        triggerHaptic('heavy');
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          rewards: {
            ...prev.rewards,
            ads: {
              ...prev.rewards.ads,
              todayCount: (prev.rewards.ads?.todayCount || 0) + 1,
              lastWatchedAt: Date.now(),
            },
          },
        }));
        setClaimMessage(`🎉 Ad reward verified! +${data.reward.toLocaleString()} SM Coins added!`);
      } else {
        setClaimMessage(data.error || 'Ad finished. Continuing game.');
      }
    } catch (err) {
      console.warn('Ad reward request error:', err);
      setClaimMessage('Ad finished. Continuing game.');
    } finally {
      setIsAdShowing(false);
      setActiveAdSlot(null);
      setTimeout(() => setClaimMessage(null), 3500);
    }
  };

  const handleAdClosed = () => {
    setIsAdShowing(false);
    setActiveAdSlot(null);
  };

  // Passive Mining calculation
  const now = Date.now();
  const lastClaimed = user.mining.lastClaimedAt || user.profile.createdAt;
  const elapsedHours = Math.min(24, Math.max(0, (now - lastClaimed) / (1000 * 60 * 60)));
  const accumulatedCoins = Math.floor(elapsedHours * user.mining.coinsPerHour);

  const handleClaimMining = async () => {
    if (accumulatedCoins <= 0 || isClaimingMining) return;
    setIsClaimingMining(true);
    triggerHaptic('medium');

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/claim-mining', {
        method: 'POST',
        headers,
      });

      const data = await res.json();
      if (res.ok) {
        updateUserState((prev) => ({
          ...prev,
          balance: data.balance,
          mining: {
            ...prev.mining,
            lastClaimedAt: data.lastClaimedAt,
          },
        }));
        setClaimMessage(`🎉 Claimed +${data.claimedAmount.toLocaleString()} passive coins!`);
      } else {
        setClaimMessage(data.error || 'Failed to claim');
      }
    } catch (err: any) {
      setClaimMessage('Network error');
    } finally {
      setIsClaimingMining(false);
      setTimeout(() => setClaimMessage(null), 3000);
    }
  };

  const energyPercent = Math.min(100, Math.max(0, Math.round((user.energy.current / user.energy.max) * 100)));
  const nextAdSlotPreview = getAdSlotForIndex(adRotationIndex, publicConfig);

  return (
    <div className="flex-1 flex flex-col justify-between max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none">
      {/* In-App Sandboxed Monetag Advertisement Modal */}
      {isAdShowing && activeAdSlot && (
        <InAppAdModal
          isOpen={isAdShowing}
          adSlot={activeAdSlot}
          onAdCompleted={handleAdCompleted}
          onAdClosed={handleAdClosed}
        />
      )}

      {/* Floating Tap Feedback Numbers (High Smooth Upward Flight) */}
      {floatingNumbers.map((fn) => (
        <div
          key={fn.id}
          className="fixed z-50 pointer-events-none font-heading font-black text-3xl sm:text-4xl text-amber-300 drop-shadow-[0_4px_16px_rgba(250,204,21,0.95)] drop-shadow-[0_0_25px_rgba(234,179,8,0.85)] animate-float-number flex items-center gap-1 select-none"
          style={{ left: `${fn.x}px`, top: `${fn.y}px` }}
        >
          <span>+{fn.value}</span>
          <span className="text-2xl filter drop-shadow">🪙</span>
        </div>
      ))}

      {/* Notification Toast */}
      {claimMessage && (
        <div className="bg-slate-800/95 border border-amber-500/50 text-amber-200 text-xs px-4 py-2.5 rounded-xl shadow-xl flex items-center justify-center gap-2 mb-3 text-center animate-fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{claimMessage}</span>
        </div>
      )}

      {/* Top Stats: Total Balance Header */}
      <div className="text-center py-2">
        <div className="text-xs uppercase tracking-wider text-slate-400 font-medium">Available Balance</div>
        <div
          className={`flex items-center justify-center gap-2 mt-1 transition-transform ${
            isBalancePopping ? 'animate-balance-pop' : ''
          }`}
        >
          <div className="w-9 h-9 rounded-full bg-amber-400 flex items-center justify-center text-slate-950 font-bold text-lg shadow-md">
            🪙
          </div>
          <span className="font-heading text-4xl font-extrabold tracking-tight text-white drop-shadow-sm">
            {user.balance.toLocaleString()}
          </span>
        </div>

        {/* Level / League Bar */}
        <div className="mt-3 flex items-center justify-between text-xs text-slate-400 px-1">
          <span className="flex items-center gap-1 font-semibold text-amber-400">
            <Award className="w-3.5 h-3.5" />
            {user.level.title} (Lv. {user.level.current})
          </span>
          <span>{user.balance.toLocaleString()} / {(user.level.current * 10000).toLocaleString()}</span>
        </div>
        <div className="w-full bg-slate-800/80 rounded-full h-2 mt-1.5 overflow-hidden border border-slate-700/50">
          <div
            className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full transition-all duration-300"
            style={{ width: `${Math.min(100, (user.balance % 10000) / 100)}%` }}
          />
        </div>
      </div>

      {/* Passive Mining Widget */}
      <div className="mt-3 bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Pickaxe className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Passive Mining</div>
            <div className="text-sm font-bold text-slate-100">
              +{accumulatedCoins.toLocaleString()}{' '}
              <span className="text-[11px] font-normal text-amber-400">({user.mining.coinsPerHour}/hr)</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleClaimMining}
          disabled={accumulatedCoins <= 0 || isClaimingMining}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
            accumulatedCoins > 0
              ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{isClaimingMining ? 'Claiming...' : 'Claim'}</span>
        </button>
      </div>

      {/* 20 Logical Taps Indicator & Ad Rotation Status */}
      <div className="mt-2.5 bg-slate-900/60 border border-slate-800/80 rounded-xl px-3 py-2 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <Tv className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-slate-300 font-medium">Ad Trigger:</span>
          <span className="font-mono font-bold text-amber-300">
            {logicalTapCount} / {TAPS_PER_AD} Taps
          </span>
        </div>
        <div className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
          Next: Zone {nextAdSlotPreview.zoneIndex + 1} (#{nextAdSlotPreview.adNumberInZone}/3)
        </div>
      </div>

      {/* Interactive Central Tap Mascot Icon Badge with Eye Wink Animation */}
      <div className="my-auto py-4 flex flex-col items-center justify-center">
        <div
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onMouseDown={handleMouseDown}
          className={`relative w-64 h-64 sm:w-72 sm:h-72 rounded-full cursor-pointer transition-transform duration-100 ease-out select-none flex items-center justify-center ${
            isPressing ? 'scale-95' : 'scale-100 hover:scale-[1.02]'
          }`}
        >
          {/* Ambient Cyber Neon Pulsing Ring */}
          <div className="absolute inset-0 rounded-full bg-cyan-500/25 blur-2xl animate-pulse" />

          {/* Outer Cyber Neon Ring Frame */}
          <div className="w-full h-full rounded-full p-2 bg-gradient-to-tr from-cyan-400 via-blue-600 to-indigo-500 shadow-[0_0_35px_rgba(6,182,212,0.65)] flex items-center justify-center">
            {/* Mascot Container */}
            <div className="w-full h-full rounded-full overflow-hidden bg-slate-950 relative border-2 border-cyan-300/70 shadow-inner flex items-center justify-center">
              <img
                src={isWinking ? tapRobotWinking : tapRobotNormal}
                alt="SM Robot Tap Mascot"
                className="w-full h-full object-cover transition-opacity duration-75 select-none pointer-events-none"
                draggable={false}
              />

              {/* Playful Wink indicator tag */}
              {isWinking && (
                <div className="absolute top-4 right-4 bg-cyan-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg animate-bounce">
                  😉 WINK!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tap Caption */}
        <div className="mt-3 flex items-center gap-1.5 text-xs text-cyan-300 font-semibold bg-slate-950/80 border border-cyan-500/30 px-3.5 py-1 rounded-full shadow-md backdrop-blur-sm">
          <span>Tap Robot • Dynamic Rewards</span>
          <span className="text-amber-400">⚡</span>
        </div>
      </div>

      {/* Bottom Energy Meter */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 shadow-lg">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <div className="flex items-center gap-1.5 font-bold text-amber-300">
            <Zap className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>Energy Battery</span>
          </div>
          <div className="font-mono text-slate-300">
            <span className="font-bold text-white">{user.energy.current}</span> / {user.energy.max}
            <span className="text-[10px] text-emerald-400 ml-1.5 font-medium">(+{user.energy.rechargeRate}/s)</span>
          </div>
        </div>

        <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
          <div
            className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 h-full rounded-full transition-all duration-300"
            style={{ width: `${energyPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
