import React, { useState, useEffect } from 'react';
import { useTelegram } from '../context/TelegramContext.tsx';
import { Trophy, Medal, Award, User, RefreshCw } from 'lucide-react';

interface LeaderboardItem {
  rank: number;
  telegramId: string;
  firstName?: string;
  username?: string;
  balance: number;
  level: number;
  totalReferred: number;
}

export const LeaderboardTab: React.FC = () => {
  const { user, simulatedTelegramId } = useTelegram();
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>([]);
  const [userRank, setUserRank] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = async () => {
    setLoading(true);
    try {
      const headers: Record<string, string> = {};
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
      }

      const res = await fetch('/api/leaderboard', { headers });
      const data = await res.json();
      if (res.ok) {
        setLeaderboard(data.leaderboard || []);
        setUserRank(data.userRank || null);
      }
    } catch (err) {
      console.error('Failed to load leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, [simulatedTelegramId]);

  const getRankBadge = (rank: number) => {
    if (rank === 1) return <span className="text-xl">🥇</span>;
    if (rank === 2) return <span className="text-xl">🥈</span>;
    if (rank === 3) return <span className="text-xl">🥉</span>;
    return <span className="font-mono text-xs font-bold text-slate-400">#{rank}</span>;
  };

  return (
    <div className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-20 select-none space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-2xl font-black text-white flex items-center gap-2">
            <span>Hall of Fame</span>
            <Trophy className="w-5 h-5 text-amber-400" />
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">Top miners across the global network</p>
        </div>
        <button
          onClick={fetchLeaderboard}
          className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-slate-200 transition"
          title="Refresh Leaderboard"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* User's Current Rank Card */}
      {user && (
        <div className="bg-gradient-to-r from-amber-500/20 via-slate-900 to-slate-900 border border-amber-500/40 rounded-2xl p-3.5 shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold">
              {userRank ? `#${userRank}` : '—'}
            </div>
            <div>
              <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                <span>Your Global Rank</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">
                  Lv. {user.level.current}
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {user.profile.firstName || 'Miner'} {user.profile.username ? `(@${user.profile.username})` : ''}
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="font-heading font-extrabold text-sm text-amber-400 flex items-center justify-end gap-1">
              <span>🪙</span>
              <span>{user.balance.toLocaleString()}</span>
            </div>
            <div className="text-[10px] text-slate-400">{user.referrals.totalReferred} invites</div>
          </div>
        </div>
      )}

      {/* Leaderboard List */}
      <div className="space-y-2">
        {loading ? (
          <div className="text-center py-8 text-xs text-slate-500">Loading rankings...</div>
        ) : leaderboard.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">No miners ranked yet. Be the first!</div>
        ) : (
          leaderboard.map((item) => {
            const isSelf = user?.profile.telegramId === item.telegramId;

            return (
              <div
                key={item.telegramId}
                className={`p-3 rounded-2xl border flex items-center justify-between transition ${
                  isSelf
                    ? 'bg-amber-500/10 border-amber-500/50 shadow-md ring-1 ring-amber-400/20'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 flex items-center justify-center shrink-0">
                    {getRankBadge(item.rank)}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                      <span>{item.firstName || `Miner ${item.telegramId.slice(-4)}`}</span>
                      {isSelf && (
                        <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1 rounded uppercase">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-2">
                      {item.username && <span>@{item.username}</span>}
                      <span>Level {item.level}</span>
                      <span>•</span>
                      <span>{item.totalReferred} friends</span>
                    </div>
                  </div>
                </div>

                <div className="font-mono text-xs font-bold text-amber-400 flex items-center gap-1">
                  <span>🪙</span>
                  <span>{item.balance.toLocaleString()}</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
