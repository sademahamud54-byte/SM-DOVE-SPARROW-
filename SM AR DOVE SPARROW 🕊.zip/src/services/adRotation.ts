import { PublicConfig } from '../types.ts';

export interface AdSlot {
  slotIndex: number; // 0 to 11
  zoneIndex: number; // 0 to 3
  zoneKey: 'zone1' | 'zone2' | 'zone3' | 'zone4';
  zoneId: string;
  adNumberInZone: number; // 1, 2, or 3
  label: string; // e.g. "Zone 1 (11924593) • Ad #1 of 3"
}

export const ADS_PER_ZONE = 3;
export const TOTAL_ZONES = 4;
export const TOTAL_AD_SLOTS = ADS_PER_ZONE * TOTAL_ZONES; // 12 slots
export const TAPS_PER_AD = 20;

const STORAGE_KEY_INDEX = 'sm_dove_ad_rotation_index';
const STORAGE_KEY_TAPS = 'sm_dove_logical_taps_count';

/**
 * Calculates slot details based on a 0-11 rotation index
 */
export function getAdSlotForIndex(slotIndex: number, publicConfig: PublicConfig | null): AdSlot {
  const normalizedIndex = ((slotIndex % TOTAL_AD_SLOTS) + TOTAL_AD_SLOTS) % TOTAL_AD_SLOTS;
  const zoneIndex = Math.floor(normalizedIndex / ADS_PER_ZONE); // 0, 1, 2, or 3
  const adNumberInZone = (normalizedIndex % ADS_PER_ZONE) + 1; // 1, 2, or 3

  const zoneKeys: Array<'zone1' | 'zone2' | 'zone3' | 'zone4'> = ['zone1', 'zone2', 'zone3', 'zone4'];
  const zoneKey = zoneKeys[zoneIndex];

  // Configuration-first zone ID lookup with fallback
  const fallbackZones = {
    zone1: '11924593',
    zone2: '11924529',
    zone3: '11924571',
    zone4: '11949016',
  };

  const zoneId = publicConfig?.monetag?.[zoneKey] || fallbackZones[zoneKey];

  return {
    slotIndex: normalizedIndex,
    zoneIndex,
    zoneKey,
    zoneId,
    adNumberInZone,
    label: `Zone ${zoneIndex + 1} (${zoneId}) • Ad #${adNumberInZone} of ${ADS_PER_ZONE}`,
  };
}

/**
 * Loads current rotation index from session storage
 */
export function loadStoredRotationIndex(): number {
  try {
    const saved = sessionStorage.getItem(STORAGE_KEY_INDEX) || localStorage.getItem(STORAGE_KEY_INDEX);
    const num = Number(saved);
    if (!isNaN(num) && num >= 0 && num < TOTAL_AD_SLOTS) {
      return num;
    }
  } catch (e) {
    // Ignore storage errors in restrictive environments
  }
  return 0;
}

/**
 * Saves rotation index to session/local storage
 */
export function saveStoredRotationIndex(index: number): void {
  try {
    const normalized = ((index % TOTAL_AD_SLOTS) + TOTAL_AD_SLOTS) % TOTAL_AD_SLOTS;
    sessionStorage.setItem(STORAGE_KEY_INDEX, normalized.toString());
    localStorage.setItem(STORAGE_KEY_INDEX, normalized.toString());
  } catch (e) {
    // Ignore storage errors
  }
}

/**
 * Loads accumulated logical taps
 */
export function loadStoredLogicalTaps(): number {
  try {
    const saved = sessionStorage.getItem(STORAGE_KEY_TAPS);
    const num = Number(saved);
    if (!isNaN(num) && num >= 0 && num < TAPS_PER_AD) {
      return num;
    }
  } catch (e) {
    // Ignore storage errors
  }
  return 0;
}

/**
 * Saves accumulated logical taps
 */
export function saveStoredLogicalTaps(taps: number): void {
  try {
    sessionStorage.setItem(STORAGE_KEY_TAPS, taps.toString());
  } catch (e) {
    // Ignore storage errors
  }
}
