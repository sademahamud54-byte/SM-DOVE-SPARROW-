import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { UserRecord, PublicConfig } from '../types.ts';

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        ready: () => void;
        expand: () => void;
        close: () => void;
        initData: string;
        initDataUnsafe?: {
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            language_code?: string;
          };
          start_param?: string;
        };
        themeParams?: any;
        colorScheme?: 'light' | 'dark';
        isExpanded?: boolean;
        viewportHeight?: number;
        viewportStableHeight?: number;
        setHeaderColor?: (color: string) => void;
        setBackgroundColor?: (color: string) => void;
        openTelegramLink?: (url: string) => void;
        openLink?: (url: string) => void;
        HapticFeedback?: {
          impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
          notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
          selectionChanged: () => void;
        };
      };
    };
  }
}

interface TelegramContextValue {
  isTelegram: boolean;
  user: UserRecord | null;
  isAdmin: boolean;
  loading: boolean;
  error: string | null;
  publicConfig: PublicConfig | null;
  simulatedTelegramId: string;
  setSimulatedTelegramId: (id: string) => void;
  refreshUser: () => Promise<void>;
  updateUserState: (updater: (prev: UserRecord) => UserRecord) => void;
  triggerHaptic: (style?: 'light' | 'medium' | 'heavy') => void;
  openExternalLink: (url: string) => void;
}

const TelegramContext = createContext<TelegramContextValue | undefined>(undefined);

export const TelegramProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isTelegram, setIsTelegram] = useState<boolean>(false);
  const [user, setUser] = useState<UserRecord | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [publicConfig, setPublicConfig] = useState<PublicConfig | null>(null);

  // Default simulated ID (stored in localStorage for convenience during testing)
  const [simulatedTelegramId, setSimulatedTelegramIdState] = useState<string>(() => {
    return localStorage.getItem('sim_tg_id') || '8801424830';
  });

  const setSimulatedTelegramId = (id: string) => {
    localStorage.setItem('sim_tg_id', id);
    setSimulatedTelegramIdState(id);
  };

  const tg = typeof window !== 'undefined' ? window.Telegram?.WebApp : undefined;

  // Initialize Telegram WebApp SDK if available
  useEffect(() => {
    if (tg && tg.initData) {
      setIsTelegram(true);
      tg.ready();
      tg.expand();
      if (tg.setHeaderColor) tg.setHeaderColor('#020617');
      if (tg.setBackgroundColor) tg.setBackgroundColor('#020617');
    } else {
      setIsTelegram(false);
    }
  }, [tg]);

  // Fetch Public Config
  useEffect(() => {
    fetch('/api/config/public')
      .then((res) => res.json())
      .then((data) => setPublicConfig(data))
      .catch((err) => console.error('Failed to load public config:', err));
  }, []);

  // Fetch User Authentication
  const authenticateUser = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      if (tg && tg.initData) {
        headers['x-telegram-init-data'] = tg.initData;
      } else {
        // Dev / Simulator mode
        headers['x-telegram-sim-user-id'] = simulatedTelegramId;
        headers['x-telegram-sim-username'] = simulatedTelegramId === '8801424830' ? 'AdminTester' : 'MinerTester';
      }

      const res = await fetch('/api/auth', {
        method: 'POST',
        headers,
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed');
      }

      setUser(data.user);
      setIsAdmin(data.isAdmin);
    } catch (err: any) {
      console.error('Auth error:', err);
      setError(err.message || 'Failed to authenticate');
    } finally {
      setLoading(false);
    }
  }, [tg, simulatedTelegramId]);

  useEffect(() => {
    authenticateUser();
  }, [authenticateUser]);

  const refreshUser = async () => {
    const headers: Record<string, string> = {};
    if (tg && tg.initData) {
      headers['x-telegram-init-data'] = tg.initData;
    } else {
      headers['x-telegram-sim-user-id'] = simulatedTelegramId;
    }

    try {
      const res = await fetch('/api/me', { headers });
      const data = await res.json();
      if (res.ok) {
        setUser(data.user);
        setIsAdmin(data.isAdmin);
      }
    } catch (err) {
      console.error('Failed to refresh user:', err);
    }
  };

  const updateUserState = (updater: (prev: UserRecord) => UserRecord) => {
    setUser((prev) => (prev ? updater(prev) : prev));
  };

  const triggerHaptic = (style: 'light' | 'medium' | 'heavy' = 'light') => {
    if (tg?.HapticFeedback) {
      try {
        tg.HapticFeedback.impactOccurred(style);
      } catch (e) {
        // Ignore haptic errors on unsupported clients
      }
    }
  };

  const openExternalLink = (url: string) => {
    if (tg?.openTelegramLink && url.includes('t.me')) {
      tg.openTelegramLink(url);
    } else if (tg?.openLink) {
      tg.openLink(url);
    } else {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <TelegramContext.Provider
      value={{
        isTelegram,
        user,
        isAdmin,
        loading,
        error,
        publicConfig,
        simulatedTelegramId,
        setSimulatedTelegramId,
        refreshUser,
        updateUserState,
        triggerHaptic,
        openExternalLink,
      }}
    >
      {children}
    </TelegramContext.Provider>
  );
};

export const useTelegram = () => {
  const context = useContext(TelegramContext);
  if (!context) {
    throw new Error('useTelegram must be used within TelegramProvider');
  }
  return context;
};
