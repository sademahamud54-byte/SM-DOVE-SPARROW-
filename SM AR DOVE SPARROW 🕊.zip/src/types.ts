export interface TelegramUserData {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

export interface UserProfile {
  telegramId: string;
  firstName: string;
  lastName?: string;
  username?: string;
  languageCode?: string;
  photoUrl?: string;
  createdAt: number;
  lastLoginAt: number;
}

export interface UserEnergy {
  current: number;
  max: number;
  rechargeRate: number;
  lastUpdated: number;
}

export interface UserMining {
  coinsPerHour: number;
  lastClaimedAt: number;
}

export interface UserUpgrades {
  tapPower: number;
  maxEnergy: number;
  rechargeRate: number;
  miningRate: number;
  multiplier: number;
}

export interface UserReferrals {
  referrerId?: string;
  totalReferred: number;
  totalEarned: number;
  referredUsers: Array<{
    telegramId: string;
    username?: string;
    bonusEarned: number;
    joinedAt: number;
  }>;
}

export interface UserRewards {
  dailyStreak: {
    currentDay: number;
    lastClaimDate: string;
  };
  ads: {
    lastWatchedAt: number;
    todayCount: number;
    todayDate: string;
  };
}

export interface UserRecord {
  profile: UserProfile;
  balance: number;
  energy: UserEnergy;
  level: {
    current: number;
    title: string;
    progress: number;
  };
  mining: UserMining;
  upgrades: UserUpgrades;
  referrals: UserReferrals;
  rewards: UserRewards;
  tasks: Record<string, { completed: boolean; claimedAt: number }>;
  statistics: {
    totalTaps: number;
    totalMined: number;
    totalAdRewards: number;
    totalTaskRewards: number;
    totalReferralRewards: number;
  };
  status: 'active' | 'banned' | 'suspended';
}

export interface TransactionRecord {
  id: string;
  userId: string;
  type: string;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  note?: string;
  timestamp: number;
}

export interface TaskDefinition {
  id: string;
  title: string;
  description: string;
  link: string;
  reward: number;
  type: 'telegram_channel' | 'telegram_group' | 'website' | 'twitter' | 'referral' | 'custom';
  status: 'active' | 'inactive';
  requiredCount?: number;
  completed?: boolean;
  claimedAt?: number | null;
  isEligible?: boolean;
}

export interface PublicConfig {
  appName: string;
  botName: string;
  botUsername: string;
  adminContact: {
    username: string;
    phone: string;
    email: string;
  };
  monetag: {
    zone1: string;
    zone2: string;
    zone3: string;
    zone4: string;
  };
  game: {
    welcomeBonus: number;
    referralBonus: number;
    baseTapReward: number;
    baseMaxEnergy: number;
    baseMiningRatePerHour: number;
    rewardPerAd: number;
    maxRewardedAdsPerDay: number;
    adCooldownSeconds: number;
    dailyRewards: number[];
  };
  isSimulatedBot: boolean;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  bannedUsers: number;
  newUsers24h: number;
  totalBalance: number;
  totalAdRewards: number;
  totalReferralRewards: number;
  totalTransactions: number;
}
